# Abnahmematrix - Works Edition 1.2.0

**Datum der automatisierten Ausfuehrung:** 2026-11-16 UTC.  
**Gesamt:** 20/20 automatisierte Tests bestanden; betriebliche Abnahme offen. Testumgebung: Python 3.13.5, Node.js 24.22.0.  
**Pilotstatus:** NICHT READY FOR PILOT.

| Testfall | Erwartet | Tatsaechlich | Datum | Status | Maengel / offene Punkte |
|---|---|---|---|---|---|
| Startdatenbank / Anlagen | 13 Anlagen, Status nicht vorbestaetigt | 13 Anlagen, Status NULL, Schema 4 | 2026-11-16 | BESTANDEN | Kein Vor-Ort-Status bestaetigt |
| 9-Schritt-Mehrbenutzerablauf | Technik-/Betriebsfreigabe getrennt; Materialstatus geordnet | HTTP-Test erfolgreich; 2 Prognosen bleiben erhalten; Statuswechsel korrekt | 2026-11-16 | BESTANDEN | Nur lokaler Testserver |
| Schichtbesonderheiten / Material / Archiv | Rollenrechte, Statusfolge, Filter | HTTP-Tests erfolgreich | 2026-11-16 | BESTANDEN | Keine reale Bedienpruefung |
| Rollen und Startpasswort | Rechte serverseitig; Passwortwechsel erzwungen | Verweigerungen und Wechsel per HTTP bestaetigt | 2026-11-16 | BESTANDEN | Firmen-Rollenfreigabe offen |
| Adminverwaltung | Passwortreset, mindestens ein aktiver Admin | Reset/Erstwechsel und Adminschutz bestaetigt | 2026-11-16 | BESTANDEN | Benutzerliste fuer Betrieb offen |
| Konflikt / Duplikat / Idempotenz | Kein stilles Ueberschreiben | Veraltete Version und doppelte Meldung werden abgewiesen; Idempotenz bestaetigt | 2026-11-16 | BESTANDEN | Keine Browser-Konfliktbedienung geprueft |
| Parallele Aenderungen | Eine Aenderung gewinnt; andere Konflikt | Genau ein HTTP-Request akzeptiert, anderer Konflikt | 2026-11-16 | BESTANDEN | Keine Last-/Mehrserverpruefung |
| Eingabe-/Fotopruefung | Fehlerhafte Daten abgewiesen | Foto-Magic-Bytes, Prioritaet und Schicht geprueft | 2026-11-16 | BESTANDEN | Keine Bilddekodierung / Malware-Pruefung |
| CSRF / Origin / Lockout | Schreibzugriff geschuetzt; Lockout sichtbar | 403 fuer CSRF/Origin, Lockout nach fuenf Fehlversuchen | 2026-11-16 | BESTANDEN | Kein externer Security-Audit |
| CLI-Smoke-Test | Initialisierung, Serverstart, Health-Endpunkt und PWA-Huelle erreichbar | Lokaler Testserver mit temporaerem Datenverzeichnis, alle vier Checks erfolgreich | 2026-11-16 | BESTANDEN | Nur HTTP auf Loopback, kein TLS |
| Schema-Migration 1 -> 4 | Vorhandene Daten und neue Pflichtspalten erhalten; Original nicht veraendert | Isolierte Kopie migriert; 13 Anlagen erhalten, Schema 4 und neue Spalten vorhanden | 2026-11-16 | BESTANDEN (isolierte Kopie) | Kein produktiver Datenbestand migriert |
| Serverneustart | Persistenz bleibt erhalten | Sitzung und Datenbank nach Prozessneustart erreichbar | 2026-11-16 | BESTANDEN | App-/Browserneustart nicht getestet |
| Backup / Restore | Integritaet, Restore, Datenvergleich; Sitzungen invalidiert | Beschaedigtes Archiv abgewiesen; gueltiger Restore, Datenvergleich und Migration Schema 3 -> 4 bestanden | 2026-11-16 | BESTANDEN (Sandbox) | IT-Backupverschluesselung und produktive Restore-Uebung offen |
| Mobile Navigation | Alle Rollenbereiche auf kleinen Bildschirmen erreichbar | Kurz-Navigation plus "Mehr"-Menue statisch geprueft; Rollenfilter bleibt aktiv | 2026-11-16 | BESTANDEN | Kein echter Touch-/Browser-Test |
| Formularfuehrung | Pflichtauswahl eindeutig; optionale Angaben nur bei Bedarf sichtbar | Drei optionale Bereiche eingeklappt; Anlage, Kategorie und Status starten ohne Vorauswahl | 2026-11-16 | BESTANDEN | Kein Nutzertest durchgefuehrt |
| Hilfe & Weblinks | Nur Admin verwaltet; HTTPS; expliziter Klick; kein Referrer/Fachdaten | Rollen, HTTPS-Validierung, Deaktivierung und sichtbare Linkliste per HTTP getestet; `noopener noreferrer`/`no-referrer` statisch geprueft | 2026-11-16 | BESTANDEN | Keine echte Zielseite oder Browser-Metadatenpruefung; Betreiber sieht uebliche Verbindungsdaten |
| Strukturelle Scope-Pruefung | Nur freigegebene Kommunikationstabellen; keine verbotenen KPI-/ERP-/Produktionsfelder | SQLite-Schema, App-Manifest und Service-Worker-API-Cache statisch geprueft | 2026-11-16 | BESTANDEN | Kein Laufzeit-/Browserbeweis |
| PWA-/iPhone-Metadaten und Bereitstellungsskripte | HTTPS-PWA und private Bereitstellungsoption | Statisch geprüft; Serve-/Hostskripte nicht auf echtem Host ausgeführt | 2026-11-16 | BESTANDEN (statisch) | Keine reale Installationsprüfung |
| TLS / Reverse Proxy / Firewall | HTTPS und nur freigegebener Zugang | Nicht auf echtem Host oder im Firmennetz eingerichtet/getestet | 2026-11-16 | OFFEN | IT-Freigabe fehlt |
| Android / iOS / Browser | Zielgeraete installiert und geprueft | Nicht durchgefuehrt; keine nativen Pakete gebaut | 2026-11-16 | OFFEN | Echte Geraete fehlen |
| Offline / Reconnect im Browser | Queue, Statusanzeige, Konflikte | Nicht auf Browser/Geraet ausgefuehrt | 2026-11-16 | OFFEN | Vor Pilot nachzuholen |
| Systemd / Betrieb / Monitoring | Neustart, Logs, Backupjob und Alarmierung | Nur Beispielkonfiguration vorhanden | 2026-11-16 | OFFEN | IT-Anpassung und Betriebsabnahme |

Ein STATUS BESTANDEN fuer automatisierte lokale Tests ist keine Freigabe fuer produktive Nutzung.
