# Installation – Works Edition 1.2.0

## Unterstützte Serverbasis

- Ubuntu 22.04 oder neuer bzw. Debian 12 oder neuer
- Python 3.10 oder neuer
- systemd und ein geschützter, verschlüsselter Datenträger
- HTTPS-Endpunkt: Tailscale Serve für begrenzte private Tests oder ein von IT freigegebener Reverse Proxy

## Automatisierte Erstinstallation

ZIP-Datei vollständig entpacken und im Projektverzeichnis ausführen:

```bash
sudo ./deploy/install-ubuntu.sh
```

Das Skript legt den dedizierten Systembenutzer `works`, `/opt/shift-supervisor-works`, `/var/lib/works`, `/etc/works/works.env` und den systemd-Dienst `shift-supervisor-works` an. Der Dienst läuft unprivilegiert und bindet an `127.0.0.1:8080`. Das Skript überschreibt keine vorhandene Installation.

Danach dem vollständigen Ablauf in `IPHONE-INSTALLATION.md` folgen. Der Administrator wird ohne Standardpasswort interaktiv angelegt:

```bash
sudo /opt/shift-supervisor-works/deploy/bootstrap-admin.sh
```

## Lokale Entwicklung

```bash
python3 server/works_server.py init-db
python3 server/works_server.py bootstrap-admin
python3 server/works_server.py serve
```

Standardmäßig läuft der lokale Entwicklungstest auf `127.0.0.1:8080` und verwendet `<Projekt>/var`. Ohne HTTPS darf kein Zugriff aus einem Netzwerk freigegeben werden.

## Produktivzugriff über Unternehmens-Reverse-Proxy

Der Python-Prozess bleibt auf Loopback. Der Reverse Proxy stellt TLS bereit, leitet intern an `127.0.0.1:8080` weiter und setzt den Host-Header unverändert. `WORKS_PUBLIC_ORIGIN` in `/etc/works/works.env` muss exakt dem externen HTTPS-Origin entsprechen; `WORKS_SECURE_COOKIE=1` ist zwingend. Die vollständigen Anforderungen stehen in `IT-BETRIEB.md`.

## Initialbestand

Beim ersten Datenbankstart werden 13 Anlagenstamm-Einträge angelegt. Ihr Status bleibt NULL/offen, bis eine Schichtleitung den realen Status vor Ort bestätigt. Es werden keine Beispielereignisse oder fiktiven Betriebsdaten angelegt.

## Status

Eine erfolgreiche Installation ist keine Pilotfreigabe. IT, Datenschutz und Betriebsverantwortliche müssen TLS, Zugriffskontrollen, Datenträger-/Backup-Verschlüsselung, Restore, iPhone-Gerätetest und fachlichen Scope freigeben.
