# Testbericht - Works Edition 1.2.0

**Ausfuehrungsdatum:** 2026-11-16 (UTC)  
**Ergebnis der automatisierten Tests:** 22/22 bestanden (14 HTTP-Integrationstests und 8 strukturelle/statische Tests).  
**Testumgebung:** Python 3.13.5, Node.js 24.22.0, Linux Sandbox; Produktziel Python 3.10 oder neuer.
**Pilotstatus:** NICHT READY FOR PILOT.

## Ausgefuehrte Tests

Die Python-Unittests starten jeweils den echten Works-HTTP-Handler auf einem lokalen Testport mit einer temporaeren SQLite-Datenbank. Es handelt sich nicht um Mock-Tests fuer Serveroperationen. Testdaten sind kuenstlich und isoliert.

- 13 Startanlagen, NULL-Status und Schema-Version 4.
- Neun-Schritt-Mehrbenutzerablauf: Meldung, Technikuebernahme, Diagnose, zwei Prognosen, technische Freigabe, betriebliche Bestaetigung, Materialbedarf und Statuswechsel.
- Prognosehistorie bleibt erhalten; Prognosen veraendern keinen Anlagenstatus.
- Rollen-/Rechtepruefung, Erstpasswortwechsel, Admin-Passwortreset und Schutz des letzten aktiven Administrators.
- Konflikte durch veraltete Versionen, doppelte Meldungen, Idempotenz, benutzeruebergreifende Vorgangs-ID und verbotene Statuswechsel.
- Parallele Statusaenderungen: genau eine gewinnt, die andere wird als Konflikt abgewiesen.
- Schichtbesonderheiten, Materialstatusreihenfolge und Archivfilter.
- Ungueltige Fotosignatur, Prioritaet, Schicht und Eingabewerte.
- CSRF, fremder Origin und Login-Lockout.
- Persistenz einer Sitzung nach Neustart des lokalen Serverprozesses.
- Backup, absichtlich beschaedigtes Backup, Restore, Sitzungsinvalidierung und Datenvergleich.
- Zwei HTTPS-Hilfelinktests: Adminrechte, Sichtbarkeit/Aktivierung sowie Ablehnung unsicherer oder mehrdeutiger URLs.
- Zwei neue UI-Regressionspruefungen fuer mobile Navigation/"Mehr" und progressive Offenlegung optionaler Formularfelder mit expliziter Pflichtauswahl.
- Restore eines Schema-3-Backups mit lokaler Migration auf Schema 4; Nutzdaten und Administrator bleiben erhalten.
- Zusaetzlicher isolierter Schema-1-zu-4-Migrationstest mit 13 erhaltenen Anlagen; die Quelldatenbank blieb unveraendert.

Statische Pruefungen: `py_compile` fuer Server und Tests, `node --check` fuer App/Service Worker/Store, JSON-Parsing des Web-App-Manifests, keine fest eingebauten externen Zieladressen und sichere Linkattribute (`noopener`, `noreferrer`, `no-referrer`) sind Teil der finalen Paketpruefung. Zusaetzlich bestand ein CLI-Smoke-Test fuer `init-db`, `serve`, `/api/health` und das Ausliefern der PWA-Huelle.

Zusätzliche Prüfungen in 1.2.0:

- Hosted-Runtime liest `PORT` und erkennt den Render-HTTPS-Host; explizite Origin-Konfiguration hat Vorrang.
- Render-Blueprint enthält eine einzelne Docker-Webinstanz und ein persistentes Volume.
- Docker-Entrypoint initialisiert das Schema und wechselt für den App-Prozess auf den unprivilegierten Benutzer `works`.
- Lokaler HTTP-Smoke-Test: `/api/health` meldet Version 1.2.0; PWA-Startseite wird ausgeliefert.
- ZIP-Archivintegrität mit `unzip -t` erfolgreich geprüft.

## Nicht durchgefuehrt

Für Version 1.2.0 wurden zusätzlich Docker-/Render-Bereitstellungskonfiguration, Single-Instance-Vorgabe, persistenten Datenträgerpfad, Port-Erkennung und HTTPS-Origin-Erkennung statisch geprüft. Der Docker-Container wurde in dieser Umgebung mangels Docker-Daemon nicht tatsächlich gebaut. Der Render-Blueprint wurde nicht auf ein echtes Cloud-Konto angewendet.

- Kein Docker-Image-Build oder Render-Deployment auf der Hostingplattform; Docker ist in der Sandbox nicht installiert.
- Kein echter Android-, iPhone- oder iPad-Test; keine nativen APK-/IPA-Pakete.
- Keine Installation/Bedienung in einem realen Browser auf Firmenhardware.
- Kein echter Offline-/Reconnect-Browserablauf; die Queue-Sortierung, Batching- und Benutzerisolation wurden statisch geprueft, nicht auf Geraeten.
- Kein TLS-/Reverse-Proxy-, Firewall-, systemd- oder Firmenkonto-Test im Kuendig-Netz.
- Kein Lasttest, Penetrationstest, Security-Audit oder Datenschutzfreigabe.
- Kein produktives Backup/Restore. Der automatisierte Restore-Test gilt nur fuer die isolierte Testdatenbank im Sandbox-Lauf.

Die automatisierten Resultate belegen lokale Softwarepfade, nicht die Eignung fuer reale Produktion oder einen Pilotbetrieb.
