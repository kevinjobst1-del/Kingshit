# Bedienung

## Startseite

Die Startseite enthaelt genau sieben Arbeitsbereiche: Anlagenuebersicht, offene Technikmeldungen, Technikbereich, Schichtbesonderheiten, Schichtuebergabe, Materialbedarf und Archiv. Profil, Benachrichtigungen und Administration sind zusaetzliche Funktionen gemaess Rolle.

Auf Mobilgeraeten stehen die vier haeufigsten Bereiche unten fest zur Verfuegung. Alle weiteren, rollenabhaengigen Bereiche sind unter **Mehr** erreichbar; Hilfe, Benachrichtigungen und Konto liegen oben. Die Startseite zeigt offene Vorgangszaehler und rollenbezogene Schnellzugriffe statt einer langen Anlagenliste.

## Formulare einfach halten

Pflichtfelder bleiben direkt sichtbar. Optionale Angaben wie Foto, Bereich, Zuordnung, Menge und Zusatzinfo sind eingeklappt und koennen bei Bedarf aufgerufen werden. Anlage, Kategorie, Schicht und Status muessen bewusst ausgewaehlt werden, statt stillschweigend den ersten Listeneintrag zu uebernehmen.

## Anlagenstatus und Technikmeldung

Eine neue Technikmeldung benoetigt Anlage, Kategorie, Beschreibung, Prioritaet und Schicht; ein Foto ist optional. Die Meldung setzt ROT und informiert Technik innerhalb der App. Technik uebernimmt die Meldung (GELB), dokumentiert Diagnose, Ursache, Massnahmen, Ersatzteile und Rueckmeldung, erfasst unverbindliche Prognosen und dokumentiert technische Pruefung/Freigabe (PINK). Vor der technischen Freigabe muessen die Dokumentationsfelder ausgefuellt sein; wenn ein Punkt nicht zutrifft oder unbekannt ist, muss das ausdruecklich eingetragen werden.

Nach PINK setzt ausschliesslich die Schichtleitung durch eine betriebliche Bestaetigung GRUEN. Technische Freigabe und betriebliche Startfreigabe sind getrennte Schritte. Eine Prognose setzt keinen Anlagenstatus und loest keine Freigabe aus.

BLAU, GRUEN und WEISS kann die Schichtleitung nur gemaess den erlaubten Statuswechseln setzen. ROT, GELB und PINK entstehen ausschliesslich im Technikablauf.

## Schichtbesonderheiten und Uebergabe

Schichtbesonderheiten bleiben ueber Schichtwechsel bestehen. Die Schichtleitung kann Eintraege uebernehmen und erledigen; Produktion kann eigene Eintraege ergaenzen. Die Schichtuebergabe wird aus offenen Technikmeldungen, Schichtbesonderheiten, abweichenden Anlagenstatus und Materialbedarf aufgebaut. Sie verlangt keine Doppeleingabe.

## Materialbedarf

Kategorien: Verpackung, Etiketten, Produktionsmaterial, Sonstiges. Menge und Einheit sind optional. Schichtleitung bearbeitet strikt in der Reihenfolge NEU -> GEPRUEFT -> BESTELLT -> GELIEFERT -> ERLEDIGT.

## Hilfe und Weblinks

Der Hilfebereich ist lokal in der App erreichbar. Administratoren koennen Linktitel, optionale Beschreibung und HTTPS-Adresse erfassen sowie Eintraege aktivieren oder deaktivieren. Ohne administrativ hinterlegte Links erscheint keine erfundene oder vorinstallierte Zieladresse.

Ein Link oeffnet sich erst nach aktivem Klick in einem neuen Tab. Works laedt externe Inhalte nicht im Hintergrund und sendet weder Works-Fachdaten noch Sitzungstoken oder Referrer an die Zielseite. Der Browser stellt anschliessend eine direkte Verbindung zur Website her; deren Betreiber kann dabei uebliche Verbindungsdaten wie IP-Adresse und Browserkennung erhalten. HTTPS schuetzt den Transport, ist aber kein Guetesiegel fuer Inhalt oder Betreiber. Nur von der Administration gepruefte Ziele oeffnen.

## Offline und Konflikte

Die App zeigt online/synchronisiert, offline, ausstehend, Fehler oder Konflikt an. Offline-Vorgaenge bleiben in der IndexedDB-Warteschlange des Browserprofils und werden nach Wiederverbindung chronologisch in kleinen Batches gesendet. Kontenanlage, Passwortaenderung und Passwort-Reset werden nie offline gespeichert.

Der Server ist autoritativ. Veraltete Versionen werden als Konflikt gemeldet; es gibt kein Last-Write-Wins. Konflikt, Berechtigungsverweigerung und Ablehnung bleiben als lokaler Entwurf sichtbar und koennen nach Pruefung verworfen werden. Eine erfolgreiche Browserannahme ist nicht gleich eine serverseitige Bestaetigung.

Offline-Entwuerfe gehoeren zum eingeloggten Benutzer. Auf gemeinsam genutzten Geraeten abmelden und Betriebssystem-/Profilzugriff schuetzen. Browserdaten sind nicht anwendungsverschluesselt.

## Archiv und Benachrichtigungen

Das Archiv filtert Zeitraum, Schicht, Anlage, Kategorie, Ersteller und Status. Es ist kein Produktions- oder Leistungsbericht und wird nicht als manipulationssicher oder zertifiziert bezeichnet. Benachrichtigungen werden per Polling abgefragt; Push wird nicht verwendet.
