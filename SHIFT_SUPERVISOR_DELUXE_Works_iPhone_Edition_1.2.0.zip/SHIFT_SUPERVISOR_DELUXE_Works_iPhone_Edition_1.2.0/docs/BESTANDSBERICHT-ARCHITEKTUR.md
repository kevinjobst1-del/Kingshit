# Bestandsbericht und Architekturentscheidung

## Ausgangslage

Universal Edition 2.1.0 wurde ausschliesslich als read-only Referenz betrachtet. Sie ist eine lokale, browserbasierte PWA mit IndexedDB und manueller Sicherung; die dort dokumentierte Architekturentscheidung lehnt zentrale Synchronisation fuer diese Version ab. Works Edition 1.0.0 war die erste eigenstaendige Projektbasis mit eigener Datenbank, API, Rollen- und Sync-Logik; Version 1.0.1 ergaenzte einen lokal verwalteten HTTPS-Hilfelinkbereich; Version 1.0.2 verbessert Navigation und Formulare ohne Schemaaenderung; Version 1.2.0 ergänzt die private iPhone-PWA-Bereitstellung über Tailscale Serve sowie Ubuntu-/Debian-Installationsskripte, ebenfalls ohne Schemaänderung. Die Universal-Dateien wurden nicht als Works-Produktdateien veraendert.

Eine Dateiliste und ein SHA-256-Abgleich bestaetigten, dass das Referenz-ZIP und dessen vorhandenes Backup bytegleich waren. Der Referenzstand bleibt ausserhalb des Works-Quellprojekts.

## Works-Architektur

- Python-Stdlib-HTTP-Server mit Threading; keine Drittanbieter-Webframeworks.
- SQLite mit WAL, Fremdschluesseln, `BEGIN IMMEDIATE`, Entity-Versionen und Idempotenz pro Benutzer/Vorgangs-ID.
- Rollenpruefung im Server; UI-Rechte allein gelten nicht als Schutz.
- PWA in Vanilla JS; Offline-Queue in IndexedDB, nach Erstellzeit sortiert, pro lokalem Benutzer markiert und in Batches gesendet.
- Konflikte werden abgewiesen und sichtbar gelassen. Kein Last-Write-Wins.
- Service Worker cached statische App-Dateien, niemals `/api/`-Antworten.
- Benachrichtigungen werden per Polling abgefragt, nicht per Push.

## Begruendung und Grenzen

Die Stdlib-/SQLite-Loesung vermeidet externe Laufzeitpakete und ist fuer eine kleine, einzelne Serverinstanz technisch ueberschaubar. Diese Wahl ist kein Nachweis fuer Lastfaehigkeit, Hochverfuegbarkeit oder Produktionsfreigabe. Es gibt keine Benchmarks und keine Skalierung auf mehrere schreibende Server.

Der Python-Server hat keinen TLS-Listener; produktiver Zugriff muss ueber HTTPS-Reverse-Proxy laufen. Native APK-/IPA-Builds, Datenbankverschluesselung, anwendungsverschluesselte Backups und Browserdatenverschluesselung sind nicht enthalten. Der Server ist nicht in das Firmennetz integriert.

## Fachlicher Scope

Keine Produktions-KPIs, OEE, Produktionsmengen/-berichte, Auftragsverwaltung, Planung, Zeiterfassung, Lager-/ERP-Funktionen, Leistungsbewertung oder komplexe QM. Die optionale Menge ist ausschliesslich Bestandteil einer Materialbedarfs-Meldung. Der Hinweis "Auftraege nicht abgeschlossen" ist lediglich eine Schichtbesonderheiten-Kategorie.

Statuswerte, technische Freigabe und betriebliche Startfreigabe sind getrennt; Prognosen loesen nie eine Freigabe aus. Die Anlageninitialwerte bleiben unbestaetigt, bis sie vor Ort kontrolliert wurden.
