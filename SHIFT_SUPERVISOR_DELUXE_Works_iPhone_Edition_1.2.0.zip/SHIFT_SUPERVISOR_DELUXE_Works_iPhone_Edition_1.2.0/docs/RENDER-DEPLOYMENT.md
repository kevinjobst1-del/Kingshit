# Render-Bereitstellung – Works Edition 1.2.0

## Was diese Vorlage einrichtet

- Docker-Webdienst in der Region Frankfurt
- HTTPS-Terminierung durch Render
- Healthcheck auf `/api/health`
- Persistentes 1-GB-Datenvolume unter `/var/lib/works`
- SQLite-Datenbank und Backups auf diesem Volume
- Secure-Cookies und serverseitige Benutzerrollen
- Container läuft nach dem Initialisieren unter dem unprivilegierten Benutzer `works`

## Wichtige Einschränkung

Ein Render-Webdienst ist über seine `onrender.com`-Adresse öffentlich aus dem Internet erreichbar. Der Works-Login bleibt vorgeschaltet, aber dies ist **kein privates Tailnet** und kein Unternehmens-VPN. Nur mit synthetischen Testdaten verwenden, bis ein zusätzlicher Zugriffsschutz (z. B. vorgeschaltetes Access-Gateway), ein Security-Review und Datenschutz-/IT-Freigabe vorhanden sind. Niemals echte Mitarbeiter-, Produktions- oder Betriebsdaten in diesen Testdienst eintragen.

Das persistente Volume benötigt einen kostenpflichtigen Dienstplan. Die `starter`-Einstellung in `render.yaml` ist absichtlich nicht Free, weil ein dauerhaftes SQLite-Volume und ein ständig verfügbarer Server benötigt werden. Vor dem Bestätigen Preis und Abrechnung im Render-Dashboard prüfen. Kein Dienst wird durch das bloße Hochladen dieses Pakets erstellt.

## Bereitstellung

1. Ein privates GitHub-Repository `SHIFT-SUPERVISOR-DELUXE` erstellen.
2. Den gesamten Inhalt dieses Projektordners in den Root dieses Repositories hochladen (einschließlich `render.yaml`, `Dockerfile` und `docker/entrypoint.sh`).
3. Render mit dem GitHub-Konto verbinden, das Zugriff auf dieses Repository hat.
4. In Render `New` → `Blueprint` wählen und das Repository auswählen.
5. Render liest `render.yaml` und zeigt einen Plan. Vor dem Anwenden Dienstplan `starter`, Frankfurt und persistentes Volume prüfen. Die URL des Dienstes wird öffentlich sein.
6. Erst nach bewusster Kosten- und Sicherheitsfreigabe den Blueprint anwenden.
7. Nach erfolgreichem Deploy im Render-Dashboard die Shell des Webdienstes öffnen und ausführen:

   ```sh
   gosu works python3 /app/server/works_server.py bootstrap-admin
   ```

   Benutzernamen, Anzeigenamen und ein starkes Startpasswort interaktiv eingeben. Keine Standard-Zugangsdaten verwenden.
8. `/api/health` prüfen, anschließend die Dienst-URL in Safari öffnen, anmelden und über „Teilen“ → „Zum Home-Bildschirm“ hinzufügen.
9. Für jede weitere Person ein eigenes Konto mit minimal erforderlicher Rolle anlegen.

## Betrieb

- SQLite darf nur auf einer einzelnen Serverinstanz mit einem einzelnen persistenten Volume betrieben werden. Keine horizontale Skalierung aktivieren.
- Render-Deploys dürfen das Volume nicht löschen. Vor Änderungen Backup exportieren und extern verschlüsselt ablegen.
- Restore und regelmäßige Sicherungs-/Wiederherstellungsübungen sind Pflicht.
- Das App-interne Backup ist nicht verschlüsselt. Es enthält sensible Betriebsdaten und muss entsprechend geschützt werden.
- Der Dienst bietet keine native IPA-Datei; Installation erfolgt als PWA über Safari.

## Lokaler Container-Smoke-Test

```sh
docker build -t shift-supervisor-works:1.2.0 .
docker run --rm -p 10000:10000 -e PORT=10000 -v works-test-data:/var/lib/works shift-supervisor-works:1.2.0
```

Danach `http://127.0.0.1:10000/api/health` prüfen. Dies ist nur ein lokaler Test ohne öffentliches TLS.
