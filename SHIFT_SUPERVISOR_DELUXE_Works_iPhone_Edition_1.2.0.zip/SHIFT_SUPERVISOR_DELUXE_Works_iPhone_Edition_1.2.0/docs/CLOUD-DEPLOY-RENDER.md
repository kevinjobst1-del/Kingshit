# Cloud deployment – Render (Works Edition 1.2.0)

## What this profile does

This repository includes a Docker image and a Render Blueprint for a single-instance Works server in Frankfurt. Render terminates public HTTPS; the container binds to `0.0.0.0` on the platform-provided `PORT`. The database and backups are written below `/var/lib/works`, which the Blueprint attaches as a persistent disk. The app process runs as an unprivileged `works` user after the entrypoint prepares the mounted directory.

The runtime derives `WORKS_PUBLIC_ORIGIN` from Render's `RENDER_EXTERNAL_HOSTNAME` environment value when an explicit origin is not supplied. An explicitly configured `WORKS_PUBLIC_ORIGIN` always takes precedence.

## Important limits

- This is an internet-reachable web service, not a private Tailscale-only endpoint. Anyone can reach the sign-in page; only users created by the administrator can sign in. Do not use real employee, production, customer, or company-confidential data in this profile before an IT/security/privacy review.
- The starter plan and persistent disk are paid Render resources. The disk is required: without it, SQLite data would be lost on redeploy/restart. Render states that attached disks are encrypted at rest, are only available to one service instance, and prevent scaling to multiple instances. This matches Works' single-writer SQLite architecture.
- The plan is intentionally single-instance (`numInstances: 1`). Do not scale this app horizontally. SQLite is not a multi-writer distributed database.
- Render's generated HTTPS address is public. Application authentication is still required. Strong unique passwords are mandatory. Do not create shared accounts.
- SQLite database/backup content and browser IndexedDB data are not application-encrypted. Use only fictional test data until encryption, access-control hardening, backup policy, and security review are approved.
- No Render account, service, Git repository, domain, or cloud resource is created by building this package. The source must be placed in a Git repository that Render can read, then the Blueprint can be applied in the Render dashboard/connected account.

## Deploy

1. Put the project source (the full contents of this folder, including `render.yaml` and `Dockerfile`) in a private Git repository.
2. In Render, create a new Blueprint and select that repository/branch.
3. Review the Blueprint preview before applying it. Confirm the region is Frankfurt and that the `works-data` persistent disk is attached at `/var/lib/works`.
4. Apply the Blueprint and wait for the deploy/health check at `/api/health` to pass.
5. In the Render service Shell, create the first administrator:

   ```bash
   gosu works python3 /app/server/works_server.py bootstrap-admin
   ```

   Choose a unique username and a strong initial password (12+ characters). The password is entered interactively and is not stored in the ZIP or environment variables.
6. Open the generated HTTPS URL in Safari on the iPhone and sign in.
7. In Safari, choose Share → Add to Home Screen → enable Open as Web App → Add.
8. Repeat the iPhone installation for each additional authorized user/device.

## After first login

- Change the initial password when prompted.
- Create an individual account for each person with the minimum required role.
- Test login, role restrictions, work-order/asset flows, and backup/restore using fictional data only.
- Confirm that the persistent disk survives a redeploy by backing up the test data, redeploying, and comparing the data after restart.
- Configure monitoring and a separately stored encrypted backup process before any real use.

## Alternative: private test

For a genuinely private limited test, use the Ubuntu/Debian VPS install plus Tailscale Serve in `docs/IPHONE-INSTALLATION.md`. In that mode the Works server binds to loopback and is reachable only through the approved tailnet. Each iPhone needs Tailscale access. Do not enable Tailscale Funnel.
