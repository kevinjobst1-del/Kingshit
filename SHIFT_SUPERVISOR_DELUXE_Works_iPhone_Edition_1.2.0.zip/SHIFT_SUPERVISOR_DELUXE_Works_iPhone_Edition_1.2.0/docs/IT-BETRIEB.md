# IT-Betrieb und Sicherheit

## Vor produktivem Netzbetrieb zwingend

- Freigabe durch IT, Datenschutz und zustaendige Betriebsverantwortliche.
- Gueltiges HTTPS/TLS am Reverse Proxy; Zugriff nur ueber den freigegebenen Origin.
- Serverprozess nur auf Loopback, Firewall sperrt den Anwendungsport fuer Clients.
- Dedizierter OS-Benutzer, restriktive Datei-/Verzeichnisrechte, verschluesselte Serverdatentraeger und verschluesselte externe Backup-Ablage.
- Monitoring fuer Prozess, Speicherplatz, SQLite-Fehler, Backup-Lauf und Restore-Test.
- Verantwortliche fuer Benutzer, Schicht-/Anlagenstamm, Stoerungen, Sicherung und Wiederherstellung.

## Privater iPhone-Testzugang mit Tailscale Serve

Für einen eng begrenzten Technik-/Gerätetest kann Tailscale Serve den lokalen Dienst über eine HTTPS-Adresse ausschließlich im angemeldeten Tailnet bereitstellen. Der Works-Prozess bleibt auf `127.0.0.1:8080`; Serve terminiert HTTPS und proxyt intern. Die Bereitstellungsskripte dazu liegen unter `deploy/`.

Pflichtmaßnahmen auch für diesen Testweg:

- Tailnet-Zugriff nur für ausdrücklich zugelassene Personen und Geräte; Freigaben regelmäßig prüfen und nicht benötigte Geräte entfernen.
- Für jede Person ein eigenes Works-Konto; keine gemeinsamen Zugangsdaten. Tailnet-Berechtigung und Works-Rolle sind getrennte Kontrollen.
- Kein öffentlicher Freigabeweg. Den Dienst nicht mit einem öffentlichen Funnel oder einer Portweiterleitung ins Internet stellen.
- Tailscale-Kontoinhaber, MFA und Wiederherstellungsweg festlegen; verlorene Geräte sofort im Tailnet sperren und die Works-Sitzung bzw. das Konto deaktivieren.
- IT/Datenschutz müssen vor echten Betriebs- oder Personaldaten den Anbieter-/Datenfluss und die organisatorische Zulässigkeit bewerten. Ein privates Tailnet ersetzt keine Firmenfreigabe.

Der alternative Firmenweg ist ein IT-freigegebener HTTPS-Reverse-Proxy mit exakt gesetztem `WORKS_PUBLIC_ORIGIN`. In beiden Fällen bleibt der App-Port 8080 für Clients gesperrt.

## Architekturgrenze

Ein Python-Prozess bedient mehrere HTTP-Threads und eine zentrale SQLite-Datenbank mit WAL und schreibenden Transaktionen. Die Anwendung ist nicht fuer horizontale Skalierung, Hochverfuegbarkeit oder mehrere schreibende Serverinstanzen ausgelegt. Vor einer groesseren Nutzerzahl oder hohem Durchsatz ist eine eigene Architektur-/Lastpruefung erforderlich; es wurden keine Leistungsbenchmarks durchgefuehrt.

Der Server stellt kein TLS bereit. `WORKS_SECURE_COOKIE=1` setzt Secure-Cookie/HSTS und setzt einen korrekt konfigurierten Tailscale-Serve-Endpunkt oder HTTPS-Reverse-Proxy voraus. Ein Flag ist kein Zertifikat und kein Schloss, wenn der Proxy offen herumsteht.

## Reverse-Proxy-Anforderungen

- Nur HTTPS nach aussen; HTTP hoechstens Redirect auf HTTPS.
- Proxy zum lokalen Python-Port; keine direkte Clientroute zum Port 8080.
- `Host` beibehalten und `WORKS_PUBLIC_ORIGIN` exakt auf den externen HTTPS-Origin setzen.
- Maximalgroesse fuer Restore-Uploads mindestens 105 MB; Serverlimit ist 100 MB.
- Request- und Access-Logs duerfen keine Cookies, Passwoerter, CSRF-Token oder Request-Bodies protokollieren.
- TLS-Versionen, Zertifikate, Erneuerung und HSTS-Richtlinie sind IT-Verantwortung.

Eine bewusst unvollstaendige Nginx-Skizze zur Anpassung durch IT:

```nginx
server {
    listen 443 ssl;
    server_name works.example.invalid;
    ssl_certificate     /etc/ssl/local/works.crt;
    ssl_certificate_key /etc/ssl/local/works.key;
    client_max_body_size 105m;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
        proxy_read_timeout 60s;
    }
}
```

Zertifikatsdateien, Cipher, Firewall und Redirect sind absichtlich nicht als fertige Unternehmenskonfiguration ausgegeben. Die IT muss sie festlegen.

## Internetlinks und ausgehender Verkehr

Works ruft externe Ziele nicht serverseitig ab. Die PWA laedt keine Drittanbieter-Skripte, Schriftarten oder Inhalte nach; die Service-Worker-Cache-Regel verarbeitet nur die eigene Herkunft und ignoriert API-/fremde Requests. Administrativ gepflegte HTTPS-Links werden erst nach ausdruecklichem Nutzerklick als direkte Browsernavigation geoeffnet. Dabei werden keine Works-Fachdaten, Sitzungstoken oder Referrer an die Zielseite angehaengt. Die Zielseite kann trotzdem die ueblichen Verbindungsdaten des Browsers sehen (typischerweise oeffentliche IP-Adresse und User-Agent); Browser, Proxy oder Sicherheitsgateway koennen zusaetzlich protokollieren. IT sollte Ziele freigeben und Egress-/Proxyregeln passend festlegen. Wenn direkte Verbindungen zu externen Zielen nicht erlaubt sind, keine solchen Links konfigurieren bzw. den Zugriff technisch ueber die Unternehmensrichtlinie sperren.

## Schutz der Daten

- **Transportverschluesselung:** nur HTTPS/TLS zwischen Browser und Reverse Proxy. Ohne TLS kein Pilot.
- **Datenbankverschluesselung:** nicht implementiert. SQLite-Datei wird mit Modus 0600 und Backup-Verzeichnis mit 0700 angelegt; WAL/SHM-Rechte muessen durch den Service-Umask geschuetzt sein. Datentraegerverschluesselung kommt von der IT.
- **Backupverschluesselung:** nicht implementiert; ZIP-Backups sind unverschluesselt. Ablage ausserhalb des Servers nur verschluesselt durch ein IT-genehmigtes Verfahren.
- **Integritaet:** SHA-256 plus SQLite `integrity_check` erkennen bestimmte Schaeden. Kein Signaturschluessel, kein Manipulationsschutz und keine Vertraulichkeit.
- **Browser-Offlinedaten:** IndexedDB ist nicht anwendungsverschluesselt; Endgeraet, Betriebssystemkonto und Browserprofil muessen geschuetzt sein.
- **Passwoerter/Sitzungen:** scrypt-Passworthashes; Session-Token werden serverseitig gehasht gespeichert. CSRF-Token und Origin-Pruefung fuer schreibende Requests. Absolut gueltige Sitzung 12 Stunden; fuenf Fehlversuche sperren die Kombination aus Benutzername/Clientadresse fuer fuenf Minuten.

Diese Kontrollen ersetzen keinen Security-Review, Penetrationstest, Datenschutzentscheid oder Incident-Prozess.

## Starten mit systemd

Für die vorbereitete Erstinstallation auf Ubuntu/Debian siehe `deploy/install-ubuntu.sh`. Es erstellt den Systembenutzer, Datenpfad und Dienst mit eingeschränkten Dateirechten. Beispieldatei: `deploy/works.service.example`. Secrets gehören nicht ins ZIP. Änderungen am Service-Environment und Reverse-Proxy-/Tailnet-Zugang bleiben Aufgabe der IT.

## Backup-Ueberwachung

Ein erfolgreicher Export prueft die SQLite-Integritaet zum Erstellungszeitpunkt. Er gilt erst nach einem erfolgreichen Restore in einer isolierten Umgebung als geprueft. Der Restore-Test muss Vergleich von Datenbestand, App-Version/Schema und Wiederanlauf enthalten. Backup- und Restore-Protokolle sind separat abzulegen.
