# Konfiguration

## Server-Umgebungsvariablen

| Variable | Standard | Bedeutung |
|---|---|---|
| `WORKS_DATA_DIR` | `<Projekt>/var` | Standardverzeichnis fuer Datenbank und Backups |
| `WORKS_DB` | `<WORKS_DATA_DIR>/works.sqlite3` | Optionaler expliziter Datenbankpfad |
| `WORKS_BACKUP_DIR` | `<WORKS_DATA_DIR>/backups` | Backup-Verzeichnis |
| `WORKS_HOST` | `127.0.0.1` | Bind-Adresse; nicht-lokaler Bind wird ohne Secure-Cookie abgebrochen |
| `WORKS_PORT` | `8080` | Lokaler HTTP-Port hinter dem Reverse Proxy |
| `WORKS_SECURE_COOKIE` | `0` | Bei `1`: Secure-/Host-Cookie und HSTS; TLS selbst kommt von Tailscale Serve oder Proxy |
| `WORKS_PUBLIC_ORIGIN` | leer | Exakter externer HTTPS-Origin fuer Origin-Pruefung |

Keine Passwoerter in Umgebungsvariablen oder Projektdateien ablegen. Das Bootstrap-Passwort wird interaktiv eingelesen.

## Benutzer

Interne Rollenwerte: `ADMINISTRATOR`, `SHIFT_LEADER` (Schichtleiter), `TECHNICIAN` (Technik), `PRODUCTION` (Produktion). Konten sind personenbezogen und werden durch Administration eingerichtet. Startpasswoerter muessen beim ersten Login geaendert werden. Rollen-, Aktivstatus- und Passwortaenderungen werden serverseitig geprueft; relevante Aenderungen beenden betroffene Sitzungen.

## Schichten

Die auswählbaren Schichtnamen sind derzeit fest `Früh`, `Spät` und `Nacht`. Benutzer und Schichten werden nicht mit festen Uhrzeiten verknuepft. Betriebliche Schichtbeginn-/Endzeiten liegen ausserhalb des Datenmodells und muessen vor einem Pilot durch den Betrieb bestaetigt werden. Nicht vorhandene Zeiten werden nicht geraten.

## Anlagen

Initial: FST 1/2, Granulierung 1-3, Muehle 1-4, Mischer 1-3, Bandtrockner. Administration kann Anlagen ergaenzen, umbenennen und deaktivieren. Statusinitialisierung erfolgt ausschliesslich nach ausdruecklicher Vor-Ort-Bestaetigung.

## Hilfe und externe Links

Administratorinnen und Administratoren verwalten die Eintraege direkt in der Works-Administration. Titel, optionale Beschreibung und URL werden in der Works-Datenbank gespeichert und an angemeldete Nutzer synchronisiert. Nur HTTPS-URLs ohne Zugangsdaten und Steuerzeichen werden akzeptiert. Es gibt keine vorbelegten URLs, keine API-Abfrage, kein automatisches Laden externer Inhalte und keine ausgehenden Works-Server-Aufrufe. Die Zielseite erhaelt bei einem Nutzerklick trotzdem uebliche Browser-Verbindungsdaten wie IP-Adresse und Browserkennung. Ein HTTPS-Link wird nicht automatisch als vertrauenswuerdig bewertet.

## Festwerte

- Anlagenstatus: ROT Defekt, GELB Technik informiert, PINK technisch geprueft/Reparatur freigegeben, BLAU wird gereinigt, GRUEN startklar, WEISS in Produktion.
- Schichtbesonderheiten (13 Kategorien): Ware fehlt; Verpackungsmaterial fehlt; Etiketten fehlen; Buchungen im Firmensystem nicht möglich; Aufträge nicht abgeschlossen; Vorreinigung; Sonderreinigung; Qualitätsprobleme; Besondere Maschineneinstellungen; Produktionsablauf geändert; Material fehlt; Technisches Problem ohne vollständigen Anlagenstillstand; Sonstiges. Status: OFFEN, ÜBERNOMMEN, ERLEDIGT.
- Materialkategorien: Verpackung, Etiketten, Produktionsmaterial, Sonstiges. Menge und Einheit sind optional und beziehen sich ausschliesslich auf Materialbedarf.
- Materialstatus: NEU, GEPRUEFT, BESTELLT, GELIEFERT, ERLEDIGT; nur in dieser Reihenfolge.
- Benachrichtigungen: In-App-Polling alle 15 Sekunden, kein Push.

## Nicht konfigurierbar in 1.2.0

Schichtzeiten, Aufbewahrungsfristen, Sprache ausser Deutsch, Push-Dienste, externe Identitaetsanbieter, mehrere Serverknoten und kundenspezifische Statusmodelle. Diese Punkte sind offene Konfiguration bzw. bekannte Einschraenkungen, keine stillschweigend angenommenen Betriebswerte.
