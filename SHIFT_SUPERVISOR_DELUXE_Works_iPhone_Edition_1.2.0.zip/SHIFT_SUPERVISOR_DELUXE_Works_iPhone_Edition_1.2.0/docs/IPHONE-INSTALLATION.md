# iPhone-Installation – Works Edition 1.2.0

## Zielbild

Die iPhone-Version ist eine installierbare Progressive Web App (PWA), keine native IPA-Datei. Sie wird über Safari geöffnet und zum Home-Bildschirm hinzugefügt. Der eigentliche Server und die zentrale Datenbank laufen dauerhaft auf einem Ubuntu-/Debian-Host.

Für einen begrenzten, privaten Test empfehlen wir Tailscale Serve:

- Der Works-Prozess bindet ausschließlich an `127.0.0.1:8080`.
- Tailscale Serve terminiert HTTPS und leitet intern an `http://127.0.0.1:8080` weiter.
- Zugriff erhalten nur berechtigte Geräte/Benutzer des Tailnet.
- Works selbst verlangt zusätzlich ein persönliches Benutzerkonto.
- Tailscale Funnel darf nicht aktiviert werden.

Tailscale Serve und Tailscale Funnel sind unterschiedliche Betriebsarten. Serve bleibt im Tailnet; Funnel macht einen Dienst öffentlich erreichbar. Siehe die offiziellen Tailscale-Dokumente unter https://tailscale.com/docs/features/tailscale-serve und https://tailscale.com/docs/reference/tailscale-cli/serve.

## Voraussetzungen

- Ein dauerhaft erreichbarer Ubuntu-22.04+- oder Debian-12+-Server (kleiner VM-/Mini-PC-Host reicht für einen begrenzten Test; Kapazität muss später gemessen werden).
- Python 3.10 oder neuer.
- SSH-/Konsolenzugriff mit sudo.
- Ein kontrolliertes Tailscale-Konto/Tailnet. Für Mitarbeiterzugriff muss die IT die Benutzer-/Gerätefreigabe und Tailnet-Zugriffsregeln festlegen.
- iPhone mit Safari und installierter Tailscale-App.
- Keine echten Betriebs- oder Personaldaten bis zur formellen Freigabe.

## A. Server vorbereiten

1. ZIP-Datei auf den Linux-Server übertragen und vollständig entpacken.
2. In das entpackte Projektverzeichnis wechseln.
3. Installation ausführen:

```bash
sudo ./deploy/install-ubuntu.sh
```

Das Skript prüft Ubuntu/Debian und Python, legt den Systembenutzer `works`, den geschützten Datenpfad `/var/lib/works`, die Konfiguration `/etc/works/works.env` und den systemd-Dienst an. Der Dienst läuft unter einem nicht privilegierten Konto und lauscht nur auf Loopback.

Prüfen:

```bash
sudo /opt/shift-supervisor-works/deploy/check-install.sh
sudo systemctl status shift-supervisor-works --no-pager
```

## B. Tailscale einrichten

1. Tailscale auf dem Server nach offizieller Installationsanleitung installieren: https://tailscale.com/docs/install/linux
2. Server anmelden:

```bash
sudo tailscale up
```

3. Im Tailscale-Adminbereich kontrollieren, dass der richtige Server im richtigen Tailnet registriert ist.
4. HTTPS-Zertifikate/HTTPS für Serve im Tailnet aktivieren, wenn Tailscale dazu auffordert.
5. Serve einrichten:

```bash
sudo /opt/shift-supervisor-works/deploy/setup-tailscale-serve.sh
```

Das Skript liest den Tailscale-MagicDNS-Namen, setzt `WORKS_PUBLIC_ORIGIN` exakt auf `https://<server>.<tailnet>.ts.net`, startet Works neu und richtet `tailscale serve --bg 8080` ein.

Status prüfen:

```bash
sudo tailscale serve status
sudo systemctl status shift-supervisor-works --no-pager
```

Es darf kein `tailscale funnel` für Works eingerichtet sein. Port 8080 darf nicht in Router, Cloud-Firewall oder Firmenfirewall nach außen freigegeben werden.

## C. Administrator anlegen

Erst wenn der Serverdienst läuft:

```bash
sudo /opt/shift-supervisor-works/deploy/bootstrap-admin.sh
```

Benutzernamen, Anzeigenamen und ein einmaliges Startpasswort werden interaktiv abgefragt. Das Startpasswort wird nicht im ZIP oder in der Konfiguration abgelegt. Danach meldet sich der Administrator über den Browser an, ändert das Startpasswort und legt für jede Person ein eigenes Konto mit passender Rolle an.

Rollen in Works:

- `ADMINISTRATOR` – Administration und Systemverwaltung
- `SHIFT_LEADER` – Schichtleitung
- `TECHNICIAN` – Technik
- `PRODUCTION` – Produktion

Keine Sammelkonten verwenden. Die Tailnet-Berechtigung und die Works-Rolle sind zwei getrennte Zugangsebenen.

## D. iPhone anbinden und PWA hinzufügen

1. Tailscale auf dem iPhone aus dem App Store installieren.
2. Mit einem Konto anmelden, das im vorgesehenen Tailnet zugelassen ist.
3. Tailscale-Verbindung aktivieren.
4. Die vom Setup-Skript ausgegebene HTTPS-Adresse in **Safari** öffnen.
5. Mit dem persönlichen Works-Benutzerkonto anmelden und das Startpasswort ändern, falls gefordert.
6. In Safari „Teilen“ öffnen.
7. „Zum Home-Bildschirm“ auswählen.
8. „Als Web-App öffnen“ aktivieren und „Hinzufügen“ tippen.

Apple beschreibt diesen Installationsweg in der iPhone-Anleitung: https://support.apple.com/guide/iphone/turn-a-website-into-an-app-in-safari-iph42ab2f3a7/ios.

Das App-Symbol wird nur auf dem iPhone hinzugefügt, auf dem der Vorgang durchgeführt wurde. Für jedes weitere iPhone wiederholen.

## E. Funktionsprüfung pro iPhone

- [ ] Tailscale verbunden; Works-Adresse nur im Tailnet erreichbar
- [ ] HTTPS-Zertifikat ohne Browserwarnung
- [ ] Login mit persönlichem Konto
- [ ] Rollenabhängige Menüs und serverseitige Rechte geprüft
- [ ] Anlage auswählen und Statusänderung mit Testdaten durchführen
- [ ] Test-Technikmeldung erstellen und bearbeiten
- [ ] Schichtbesonderheit erstellen/übernehmen/erledigen
- [ ] Materialbedarf erstellen und Statusfolge prüfen
- [ ] Archiv öffnen und filtern
- [ ] App schließen und neu öffnen; Anmeldung/Sitzung prüfen
- [ ] WLAN/Mobilfunk-Wechsel und Offline-/Reconnect-Verhalten prüfen
- [ ] Benutzerwechsel prüfen; keine lokale Warteschlange darf dem falschen Benutzer zugeordnet werden
- [ ] Logout auf gemeinsam genutzten Geräten

## F. Hinweise für den laufenden Betrieb

- Der Server muss laufen und erreichbar sein; die PWA ist kein autarker iPhone-Server.
- Offline können zuletzt lokal gespeicherte Daten angezeigt und neue Vorgänge in die gerätegebundene Warteschlange gelegt werden. Diese Vorgänge sind erst nach erfolgreicher Synchronisation serverseitig bestätigt.
- Keine API-Daten werden durch den Service Worker zwischengespeichert. Die Benutzeroberfläche und statische Dateien werden für die PWA bereitgestellt.
- Benachrichtigungen werden bei geöffneter App alle 15 Sekunden abgefragt. Es gibt keinen Push-Dienst.
- Sitzungen sind auf 12 Stunden begrenzt. Nach Ablauf ist eine erneute Anmeldung nötig.
- Auf gemeinsam genutzten Geräten nach jeder Schicht abmelden und keine Zugangsdaten im Browser speichern.

## Rückweg / Abschalten

Tailscale Serve deaktivieren:

```bash
sudo tailscale serve reset
```

Works stoppen:

```bash
sudo systemctl disable --now shift-supervisor-works
```

Die Daten liegen weiterhin in `/var/lib/works`. Vor Löschen oder Neuinstallation zuerst ein kontrolliertes Backup erstellen und gemäß IT-Verfahren verschlüsselt ablegen.
