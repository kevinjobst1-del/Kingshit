# Pilotplan

## Aktueller Entscheid

**NICHT READY FOR PILOT.** Ein Pilot ist gesperrt, bis alle Pflicht-Gates dokumentiert freigegeben sind. Technisch lokal getestet heisst nicht: Firmenbetrieb darf jetzt loslaufen.

## Pflicht-Gates vor Pilot

1. IT, Datenschutz und Betriebsverantwortliche geben Datenmodell, Rollen, Aufbewahrung, Zugriff und Serverstandort frei.
2. IT richtet TLS (Tailscale Serve nur für einen privaten Test oder einen freigegebenen Firmen-Reverse-Proxy), Zugriffsregeln, Firewall, systemd, Datei-/Verzeichnisrechte, Monitoring und Backup-Ablage ein.
3. IT fuehrt einen erfolgreichen Restore-Test auf separater Testinstanz mit Datenvergleich durch und dokumentiert ihn.
4. Verantwortliche bestaetigen Benutzerliste, Schichtbezeichnungen und reale Schichtzeiten. Zeiten sind in 1.2.0 nicht modelliert.
5. Echte Zielgeraete (Android und iOS, soweit im Betrieb genutzt) werden installiert und im Browser/PWA-Modus getestet. Für iOS sind Tailscale-Verbindung, Safari-Installation, Wiederanmeldung und Offline-/Reconnect-Verhalten einzeln nachzuweisen.
6. Offline, Wiederverbindung, Konflikt, App-Neustart und Benutzerwechsel werden auf den Zielgeraeten geprueft; keine Queue darf einem anderen Benutzer zugeordnet werden.
7. Verantwortliche bestaetigen, dass die Software nur Kommunikation/Organisation abbildet und keine Produktions-/Leistungsbewertung ersetzt.
8. Bekannte Einschränkungen werden von Pilotverantwortlichen akzeptiert; Rueckfall- und Supportweg stehen fest.
9. IT/Datenschutz pruefen die administrativ gepflegten HTTPS-Zielseiten und bestaetigen, dass der direkte Browserzugriff samt ueblichen Verbindungsdaten betrieblich zulaessig ist.

## Vorgeschlagener Ablauf nach Freigabe

- **Phase 0 - IT-Test:** isolierte Testinstanz, keine echten Betriebsdaten; Infrastruktur- und Restore-Gates.
- **Phase 1 - Geraetetest:** kleine, freiwillige Nutzergruppe; App-Start, Status, Meldung, Uebergabe, Offline und Konflikte.
- **Phase 2 - begrenzter Pilot:** ein klar begrenzter Bereich und definierte Dauer, taegliche Sichtung von Fehlern und Queue-Konflikten.
- **Phase 3 - Abnahme:** Matrix aktualisieren, offene Maengel priorisieren, Betriebs-/IT-Freigabe protokollieren.
- **Go/No-Go:** schriftlich durch IT und fachlich Verantwortliche; bis dahin bleibt der Status NICHT READY FOR PILOT.

Es werden hier keine Namen, Schichtzeiten oder Pilotdaten erfunden; sie sind durch den Betrieb zu bestimmen.
