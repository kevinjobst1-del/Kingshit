# Aenderungsprotokoll

## Works Edition 1.2.0 - 2026-11-16

- Docker-Container mit nicht privilegiertem Laufzeitbenutzer, persistenter Datenablage und Plattform-Port-Unterstützung.
- Render-Blueprint: eine Instanz in Frankfurt, Healthcheck `/api/health`, persistenter Datenträger `/var/data`.
- Automatische HTTPS-Origin-Erkennung für Render/Railway, explizite Origin-Konfiguration hat Vorrang.
- Neue Deployment-Dokumentation für Cloudbereitstellung; keine Cloud-Ressource wurde in dieser Arbeitsumgebung angelegt.

- Bereitstellungsprofil für iPhone/PWA über Tailscale Serve dokumentiert: privates HTTPS im Tailnet, kein öffentlicher Funnel.
- Ubuntu-/Debian-Installationsskript mit dediziertem Systemkonto, systemd-Härtung, Loopback-Bindung und geschütztem Datenpfad ergänzt.
- Admin-Bootstrap, Tailscale-Serve-Setup und Healthcheck-Skripte ergänzt.
- iPhone-Safari-Installationsanleitung, Mehrbenutzer-/Serverarchitektur und Geräteabnahmeschritte ergänzt.
- PWA-Metadaten und Datumsformat auf Deutsch (Deutschland) gestellt; Service-Worker-Cache aktualisiert. Datenbankschema bleibt Version 4.
- Die bestehende Server-/Rollen-/Workflow-Logik und die gespeicherten Datenformate bleiben erhalten; keine Migration des Datenbankschemas erforderlich.
- Testumfang um PWA-/Deployment-Prüfungen ergänzt. Kein echter Server-, Tailnet- oder iPhone-Test durchgeführt; Status bleibt NICHT READY FOR PILOT.

## Works Edition 1.0.2 - 2026-11-16

- Rollenorientierte, aufgeraeumte Startseite mit schnell erreichbaren Aufgaben und kompakter Anzeige offener Vorgaenge.
- Mobile Navigation repariert: vier haeufige Bereiche plus "Mehr" fuer alle weiteren, rollenabhaengigen Seiten.
- Stoerungs-, Schichtinfo- und Materialformulare vereinfacht; optionale Angaben eingeklappt und Anlagen/Kategorien/Status muessen bewusst ausgewaehlt werden.
- Visuelles System mit klarerer Hierarchie, ruhigeren Flaechen und konsistenten Aktionskarten ueberarbeitet.
- Service-Worker-Cache auf 1.0.2 aktualisiert; Datenbankschema bleibt Version 4.
- 19/19 automatisierte Tests bestanden; weiterhin keine echten Browser-/Geraetetests oder Pilotfreigabe.

## Works Edition 1.0.1 - 2026-11-16

- Lokalen Bereich "Hilfe & Weblinks" ergaenzt; Administratoren verwalten HTTPS-Links und koennen sie deaktivieren.
- Serverseitige HTTPS-Validierung lehnt HTTP, andere Schemes, Zugangsdaten, Whitespace/Steuerzeichen und mehrdeutige URL-Formen ab.
- Externe Ziele werden ausschliesslich nach aktivem Klick im Browser geoeffnet. Keine automatischen externen Abrufe, keine Fachdaten, Sitzungstoken oder Referrer an Zielseiten; uebliche Browser-Verbindungsdaten bleiben sichtbar.
- SQLite-Schema auf Version 4 erweitert; Service-Worker-Cache aktualisiert. Schema-3-Backups werden beim Restore lokal auf Schema 4 migriert.
- 17/17 automatisierte Tests bestanden (14 HTTP-Integrationstests und 3 statische/strukturelle Tests); isolierter Schema-1-zu-4-Migrationstest und CLI-Smoke-Test ebenfalls bestanden.
- Sicherheits- und Restore-Tests erweitert; Pilotstatus bleibt NICHT READY FOR PILOT.

## Works Edition 1.0.0 - 2026-11-08

- Eigenstaendiges PWA-/Serverprojekt angelegt; Universal Edition 2.1.0 bleibt unveraendert und dient nur als read-only Referenz.
- Python-Stdlib-Server und SQLite/WAL mit Schema-Version 3, Rollenpruefung, Versionskonflikten, Idempotenz, Sessions, CSRF/Origin und Login-Lockout umgesetzt.
- Startpasswortwechsel serverseitig erzwungen; Admin-Passwortreset invalidiert betroffene Sitzungen.
- Technische Rueckmeldung um dauerhaft sichtbares Feedback erweitert; technische Freigabe erst nach vollstaendiger Dokumentation.
- Offline-Warteschlange pro Benutzer isoliert, zeitlich sortiert und in kleine HTTP-Batches aufgeteilt.
- Materialkategorien/-status lokalisiert; Prognose verlangt Datum, Uhrzeit und Freitext.
- Backup-/Restore-Schema und Spaltenpruefung erweitert; Restore invalidiert Sitzungen und protokolliert die Wiederherstellung.
- 12 lokale HTTP-Integrationstests plus zwei strukturelle/statische Tests (14/14 bestanden) gegen echte temporaere SQLite-Serverinstanzen erstellt und bestanden.
- Grenzen dokumentiert: kein TLS-Listener, keine DB-/Backup-/Browserdatenverschluesselung, kein Push, keine nativen Builds, keine echten Geraetetests.
