# Backup und Restore

## Backup erstellen

Administratoren koennen serverseitig ein ZIP-Backup anfordern. Es enthaelt `works.sqlite3` und `manifest.json` mit Schema, Groesse, Erstellzeit, SHA-256 und SQLite-Integritaetsstatus. Die Datei ist nicht verschluesselt und nicht signiert. Die Integritaetspruefung ersetzt keinen Restore-Test.

Das Backup erst dann als **geprueft** kennzeichnen, wenn die Datei in einer isolierten Umgebung erfolgreich wiederhergestellt und der erwartete Datenbestand verglichen wurde. Das Browser-UI kann externe Ablageorte oder spaetere Verfuegbarkeit nicht nachweisen.

## Restore

1. Alle Benutzer auffordern, online zu synchronisieren. Offline-Warteschlangen auf allen Geraeten zuerst klaeren; die Serverdatenbank kann fremde lokale Warteschlangen nicht sehen.
2. Restore-Datei aus einer kontrollierten, IT-geschuetzten Ablage auswaehlen und SHA-/Herkunft nach dem betrieblichen Verfahren pruefen.
3. In der Works-Administration `RESTORE` exakt bestaetigen und wiederherstellen.
4. Der Server validiert Archivnamen, ZIP-Inhalt, Manifest, Hash, Schema, benoetigte Tabellen/Spalten, SQLite-Integritaet, Fremdschluessel und aktiven Administrator. Schema-3-Backups aus Works Edition 1.0.0 werden nach erfolgreicher Pruefung lokal und additiv auf Schema 4 migriert; Schema 1/2-Backups werden nicht akzeptiert.
5. Vor dem Austausch erstellt der Server eine Sicherheitssicherung. Die DB-Datei wird atomar ersetzt; alle Server-Sitzungen werden invalidiert.
6. Administrator meldet sich erneut an; Datenbestand und Funktionen verifizieren. Das Restore-Auditereignis wird in der wiederhergestellten Datenbank protokolliert.
7. Backup-Datei gemaess IT-Richtlinie verschluesselt ablegen und Aufbewahrung/Loeschung dokumentieren.

Restore ersetzt den Datenbestand auf dem Server durch den Stand des Backups. Aenderungen nach dem Backup koennen verloren gehen. Andere Browser koennen lokale Entwuerfe besitzen; diese werden nicht durch Server-Restore geloescht. Deshalb vor Restore Wartungsfenster und Queue-Abgleich.

## Sicherheitshinweise

SHA-256 ist Integritaetskontrolle, kein Authentizitaetsbeweis. ZIP-Backups enthalten unverschluesselte personenbezogene und betriebliche Inhalte. Datei- und Backupverzeichnisrechte, Datentraegerverschluesselung, externe Backupverschluesselung und Zugriffskontrolle muessen von der IT kommen.
