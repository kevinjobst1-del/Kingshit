# Bekannte Einschraenkungen

- Status: **NICHT READY FOR PILOT** bis IT-Freigabe, TLS, reale Geraetetests und Restore-uebung abgeschlossen sind.
- Server startet nicht mit eigenem TLS; Tailscale Serve (privater Tailnet-Zugang) oder ein freigegebener HTTPS-Reverse-Proxy ist Pflicht. TLS wurde weder auf einem echten Host noch im Firmennetz getestet.
- SQLite-Datei ist nicht anwendungsverschluesselt. Backups sind unverschluesselt; SHA-256 ist keine Signatur und bietet keine Vertraulichkeit.
- IndexedDB-Offlinedaten sind nicht anwendungsverschluesselt und koennen lokal nicht gegen Zugriff auf ein entsperrtes Browserprofil schuetzen.
- Kein Push: In-App-Benachrichtigungen werden bei laufender App per 15-Sekunden-Polling abgefragt.
- Keine nativen Android-/iOS-Builds und keine echten Geraetetests. Die vorbereitete iPhone-Bereitstellung ist eine PWA über HTTPS, kein natives App-Store-Paket.
- Offline-/Reconnect-Ablauf wurde nicht im realen Browser/Geraet ausgefuehrt.
- Ein Prozess/eine Serverinstanz; keine horizontale Skalierung, Hochverfuegbarkeit oder Performance-Zusage. Keine Benchmarks.
- Keine Benutzer-, Schichtzeit- oder Standortdaten vorgegeben. Schichtnamen sind fest; Schichtzeiten werden nicht erfasst.
- Keine Aufbewahrungs-/Loeschautomatik, kein externer Identity-Provider und keine Mehr-Faktor-Authentisierung.
- HTTPS-Links werden nur auf Schema und URL-Syntax geprueft; es gibt keine zentrale Domain-Allowlist oder Qualitaetspruefung. Administration muss Ziele vor Freigabe pruefen. Beim Klick sieht die Zielwebsite uebliche Browser-Verbindungsdaten.
- Keine Security-/Penetrationstests, Datenschutzfreigabe oder Zertifizierung.
- Backup-Integritaetspruefung ersetzt keine regelmaessige Restore-Uebung. Die erfolgreiche Restore-Pruefung der Test-Suite gilt nur fuer deren isolierte Testdatenbank.
- Die iPhone-PWA wurde nicht auf einem realen iPhone/Safari installiert oder bedient. Die Ubuntu-/Debian-Installationsskripte wurden nur statisch geprüft, nicht auf einem echten Server ausgeführt.
