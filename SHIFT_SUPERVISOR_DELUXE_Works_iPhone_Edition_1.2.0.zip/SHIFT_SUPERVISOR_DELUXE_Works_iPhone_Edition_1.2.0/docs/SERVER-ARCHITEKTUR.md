# Serverarchitektur – Works Edition 1.2.0

## Aufbau

```text
 iPhone / iPad / Desktop-Browser
   ├── Tailscale-Client (Zugriffsberechtigung im Tailnet)
   └── Safari / Web-App (Works-Login, Session-Cookie, CSRF)
                 │ HTTPS
                 ▼
       Tailscale Serve (TLS-Endpunkt)
                 │ localhost / HTTP
                 ▼
       127.0.0.1:8080 – Works Python-Server
                 │
                 ▼
       SQLite/WAL – zentrale Datenbank
       /var/lib/works/works.sqlite3
```

Für einen Firmenbetrieb kann der Tailscale-Endpunkt durch einen von der IT freigegebenen HTTPS-Reverse-Proxy ersetzt werden. Der Python-Server bleibt in beiden Fällen auf Loopback gebunden; der Anwendungsport wird nicht direkt für Clients geöffnet.

## Benutzer- und Datenfluss

1. Die Person verbindet das Gerät mit dem zugelassenen Tailnet bzw. Firmennetz.
2. Der Browser erreicht die Works-PWA über HTTPS.
3. Works prüft das persönliche Konto und die lokale Rollenberechtigung.
4. Schreibende API-Vorgänge benötigen Session, CSRF-Token und passende serverseitige Rolle.
5. Daten werden zentral in einer SQLite-Datenbank gespeichert; alle angemeldeten Rollen sehen die jeweils freigegebenen Vorgänge über ihre API-Snapshots.
6. IndexedDB hält lokale Offline-Daten und eine benutzergebundene Synchronisationswarteschlange. Versionskonflikte werden nicht still überschrieben.

## Mehrbenutzerrollen

| Rolle | Zweck |
|---|---|
| Administrator | Benutzer, Rollen, Anlagenstamm, Administration, Backup/Restore |
| Schichtleiter | Schichtorganisation, Anlagenstatus, Störungen, Übergaben und Archiv entsprechend Berechtigungen |
| Technik | Technische Bearbeitung und Rückmeldung von Störungen |
| Produktion | Meldungen und Informationen im freigegebenen Produktionsumfang |

Die sichtbare Navigation ist keine Sicherheitsgrenze. Entscheidend ist die Rollenprüfung auf dem Server.

## Betriebsgrenzen

- Ein Python-Prozess und eine SQLite-Datenbank auf einem Host.
- Threading und Transaktionen mit SQLite/WAL; keine horizontale Skalierung.
- Keine Hochverfügbarkeit, kein automatisches Failover und kein Leistungsbenchmark.
- Ein paralleler zweiter Schreibserver ist nicht unterstützt.
- Die Datenbank ist nicht auf Anwendungsebene verschlüsselt.
- Backups aus der bestehenden Web-Administration sind unverschlüsselte ZIP-Dateien.
- Offline-Daten im Browser sind nicht anwendungsverschlüsselt.
- Keine native iOS-App/IPA; das iPhone verwendet eine PWA.

Für größere Last, mehrere Standorte oder Hochverfügbarkeit ist vorab eine eigenständige Architekturprüfung (z. B. Datenbankwechsel, Migrations- und Lastkonzept) notwendig.
