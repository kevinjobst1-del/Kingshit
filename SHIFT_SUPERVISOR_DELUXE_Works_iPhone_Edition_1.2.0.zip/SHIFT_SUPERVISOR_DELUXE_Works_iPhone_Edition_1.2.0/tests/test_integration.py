"""HTTP-level integration tests; these exercise the real local server, not a mock."""
import base64
import concurrent.futures
import http.client
import hashlib
import json
import os
import stat
import sqlite3
import tempfile
import threading
import unittest
import uuid
import zipfile
from io import BytesIO
from pathlib import Path
from http.server import ThreadingHTTPServer

from server.works_server import WorksHandler, WorksStore, hash_password

ROOT = Path(__file__).resolve().parents[1]

class QuietHandler(WorksHandler):
    def log_message(self, fmt, *args):
        pass

class ApiClient:
    def __init__(self, port):
        self.port = port
        self.cookie = ""
        self.csrf = ""
        self.user = None

    def request(self, method, path, data=None, raw=None, headers=None, csrf=True, origin=None):
        hdr = dict(headers or {})
        body = raw
        if data is not None:
            body = json.dumps(data, ensure_ascii=False).encode()
            hdr.setdefault("Content-Type", "application/json")
        if self.cookie:
            hdr["Cookie"] = self.cookie
        if csrf and method in ("POST", "PUT", "PATCH", "DELETE") and self.csrf:
            hdr["X-CSRF-Token"] = self.csrf
        if origin is not None:
            hdr["Origin"] = origin
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=15)
        conn.request(method, path, body=body, headers=hdr)
        response = conn.getresponse()
        raw_result = response.read()
        status = response.status
        response_headers = dict(response.getheaders())
        cookie = response_headers.get("Set-Cookie", "")
        if cookie:
            self.cookie = cookie.split(";", 1)[0]
        content_type = response_headers.get("Content-Type", "")
        conn.close()
        if "application/json" in content_type:
            try:
                result = json.loads(raw_result.decode("utf-8"))
            except Exception:
                result = None
        else:
            result = raw_result
        return status, result, response_headers

    def login(self, username, password):
        status, result, _ = self.request("POST", "/api/login", {"username": username, "password": password}, csrf=False)
        if status != 200:
            raise AssertionError(f"login failed: {status} {result}")
        self.csrf = result["csrf"]
        self.user = result["user"]
        return result

    def op(self, typ, entity_id=None, payload=None, base_version=None, asset_version=None, op_id=None):
        operation = {"op_id": op_id or "test-" + uuid.uuid4().hex, "type": typ,
                     "entity_id": entity_id or uuid.uuid4().hex, "payload": payload or {}}
        if base_version is not None:
            operation["base_version"] = base_version
        if asset_version is not None:
            operation["asset_version"] = asset_version
        status, result, _ = self.request("POST", "/api/sync", {"operations": [operation]})
        if status != 200:
            raise AssertionError(f"sync HTTP {status}: {result}")
        return result["results"][0]

class WorksIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="works-test-")
        base = Path(self.tmp.name)
        self.store = WorksStore(base / "works.sqlite3", base / "backups")
        self.store.bootstrap_admin("admin", "Admin User", "Admin-Start-Password-42")
        self._add_user("production", "Mitarbeitende Produktion", "PRODUCTION")
        self._add_user("technik", "Technik Person", "TECHNICIAN")
        self._add_user("schicht", "Schicht Leitung", "SHIFT_LEADER")
        self.httpd = None
        self.thread = None
        self._start_server()
        self.port = self.httpd.server_address[1]

    def tearDown(self):
        self._stop_server()
        self.tmp.cleanup()

    def _add_user(self, username, display, role, password="User-Start-Password-42"):
        import sqlite3
        ts = "2026-01-01T00:00:00Z"
        conn = sqlite3.connect(self.store.db_path)
        try:
            conn.execute("INSERT INTO users(id,username,display_name,role,password_hash,active,must_change,created_at,updated_at) VALUES(?,?,?,?,?,1,0,?,?)",
                         ("user-" + username, username, display, role, hash_password(password), ts, ts))
            conn.commit()
        finally:
            conn.close()

    def _start_server(self):
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), QuietHandler)
        self.httpd.store = self.store
        self.httpd.app_dir = ROOT / "app"
        self.httpd.secure_cookie = False
        self.httpd.public_origin = ""
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    def _stop_server(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.thread.join(timeout=3)
            self.httpd = None

    def client(self, username="admin", password="Admin-Start-Password-42"):
        c = ApiClient(self.httpd.server_address[1])
        c.login(username, password)
        return c

    def snapshot(self, client):
        status, data, _ = client.request("GET", "/api/snapshot")
        self.assertEqual(status, 200, data)
        return data

    def fault_report(self, client, asset="fst-1", **extra):
        asset_version = extra.pop("asset_version", 1)
        payload = {"asset_id": asset, "asset_version": asset_version, "category": "Motor / Antrieb",
                   "description": "Ungewöhnliches Geräusch, Anlage bitte prüfen.", "priority": "HOCH", "shift": "Früh"}
        payload.update(extra)
        return client.op("fault.create", "fault-test-" + uuid.uuid4().hex[:12], payload, asset_version=asset_version)

    def test_seed_assets_and_status_unconfirmed(self):
        admin = self.client()
        data = self.snapshot(admin)
        self.assertEqual(len(data["assets"]), 13)
        self.assertTrue(all(a["status"] is None for a in data["assets"]))
        self.assertEqual(data["schema_version"], 4)
        self.assertEqual(data["app_version"], "1.2.0")
        self.assertEqual(data["assets"][0]["active"], 1)
        self.assertEqual(stat.S_IMODE(self.store.db_path.stat().st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(self.store.backup_dir.stat().st_mode), 0o700)

    def test_server_side_roles_and_forced_password_change(self):
        admin = self.client()
        prod = self.client("production", "User-Start-Password-42")
        result = admin.op("admin.user.create", "user-newtech", {"username":"newtech", "display_name":"Neue Technik", "role":"TECHNICIAN", "password":"Initial-Password-987"})
        self.assertEqual(result["status"], "accepted")
        status, data, _ = prod.request("GET", "/api/archive")
        self.assertEqual(status, 403)
        denied = prod.op("admin.user.create", "hacked-user", {"username":"hacked", "display_name":"Nope", "role":"ADMINISTRATOR", "password":"Something-Long-987"})
        self.assertEqual(denied["status"], "denied")
        new_user = self.client("newtech", "Initial-Password-987")
        self.assertTrue(new_user.user["must_change"])
        status, _, _ = new_user.request("GET", "/api/snapshot")
        self.assertEqual(status, 403)
        blocked = new_user.op("asset.status", "fst-1", {"status":"START_READY", "initial_confirmed":True, "shift":"Früh"}, base_version=1)
        self.assertEqual(blocked["status"], "denied")
        changed = new_user.op("user.password.change", new_user.user["id"], {"current_password":"Initial-Password-987", "new_password":"New-Long-Password-765"})
        self.assertEqual(changed["status"], "accepted")
        self.assertEqual(self.snapshot(new_user)["role"], "TECHNICIAN")
        self.assertFalse(new_user.request("GET", "/api/me")[1]["user"]["must_change"])

    def test_full_nine_step_multirole_workflow_and_prognosis_history(self):
        prod = self.client("production", "User-Start-Password-42")
        tech = self.client("technik", "User-Start-Password-42")
        lead = self.client("schicht", "User-Start-Password-42")
        fault_id = "fault-nine-step"
        # 1. Production reports; the server sets RED and notifies Technology.
        report = prod.op("fault.create", fault_id, {"asset_id":"fst-1", "asset_version":1, "category":"Antrieb", "description":"Motor läuft auffällig laut.", "priority":"HOCH", "shift":"Früh"}, asset_version=1)
        self.assertEqual(report["status"], "accepted")
        # 2. Technology accepts the report; RED becomes YELLOW.
        accept = tech.op("fault.accept", fault_id, {}, base_version=1, asset_version=2)
        self.assertEqual(accept["status"], "accepted")
        # 3. Diagnose, cause, measures, parts and feedback are recorded.
        diagnose = tech.op("fault.diagnose", fault_id, {"diagnosis":"Lager prüfen", "cause":"Verschleiß", "measures":"Sichtprüfung", "parts":"Lager", "comment":"Rückmeldung an Schicht"}, base_version=2)
        self.assertEqual(diagnose["status"], "accepted")
        # 4-5. Two forecasts are appended; neither changes the asset status.
        forecast1 = tech.op("fault.forecast", fault_id, {"label":"Bis zum Ende des heutigen Tages", "eta_date":"2026-01-02", "eta_time":"18:00", "note":"Unverbindlich"}, base_version=3)
        forecast2 = tech.op("fault.forecast", fault_id, {"label":"Mehrere Tage", "eta_date":"2026-01-05", "eta_time":"12:00", "note":"Neue Einschätzung"}, base_version=4)
        self.assertEqual(forecast1["status"], "accepted")
        self.assertEqual(forecast2["status"], "accepted")
        self.assertEqual(next(a for a in self.snapshot(lead)["assets"] if a["id"]=="fst-1")["status"], "TECH_INFORMED")
        # 6. Technical testing and release remain a separate action.
        release = tech.op("fault.release", fault_id, {"repair_note":"Lager ersetzt", "technical_test":"Technisch geprüft"}, base_version=5, asset_version=3)
        self.assertEqual(release["status"], "accepted")
        # 7. Only the shift leader confirms operational START_READY.
        close = lead.op("fault.close", fault_id, {"operational_note":"Vor Ort geprüft; Startklar", "asset_version":4}, base_version=6)
        self.assertEqual(close["status"], "accepted")
        # 8. Production requests material.
        material = prod.op("material.create", "material-nine-step", {"name":"Lager", "category":"Produktionsmaterial", "quantity":"2", "unit":"Stück", "asset_id":"fst-1", "area":"Technik", "description":"Ersatzbedarf", "shift":"Früh"})
        self.assertEqual(material["status"], "accepted")
        # 9. Shift leader advances the material one step, not straight to delivered.
        checked = lead.op("material.status", "material-nine-step", {"status":"CHECKED"}, base_version=1)
        self.assertEqual(checked["status"], "accepted")
        data = self.snapshot(lead)
        asset = next(a for a in data["assets"] if a["id"]=="fst-1")
        fault = next(f for f in data["faults"] if f["id"]==fault_id)
        self.assertEqual(asset["status"], "START_READY")
        self.assertEqual(fault["status"], "CLOSED")
        self.assertEqual(len(fault["forecasts"]), 2)
        self.assertEqual(fault["forecasts"][0]["label"], "Mehrere Tage")
        self.assertEqual(next(m for m in data["materials"] if m["id"]=="material-nine-step")["status"], "CHECKED")
        tech_notifications = tech.request("GET", "/api/notifications")[1]["items"]
        self.assertTrue(any(n["entity_id"]==fault_id for n in tech_notifications))

    def test_conflicts_duplicate_idempotency_and_status_guards(self):
        prod = self.client("production", "User-Start-Password-42")
        tech = self.client("technik", "User-Start-Password-42")
        lead = self.client("schicht", "User-Start-Password-42")
        status, res, _ = lead.request("POST", "/api/sync", {"operations":[{"op_id":"init-no-confirm", "type":"asset.status", "entity_id":"fst-1", "payload":{"status":"START_READY", "initial_confirmed":False, "shift":"Früh"}, "base_version":1}]})
        self.assertEqual(res["results"][0]["status"], "rejected")
        illegal = lead.op("asset.status", "fst-1", {"status":"DEFECT", "initial_confirmed":True, "shift":"Früh"}, base_version=1)
        self.assertEqual(illegal["status"], "rejected")
        fake_confirmation = lead.op("asset.status", "fst-1", {"status":"START_READY", "initial_confirmed":"false", "shift":"Früh"}, base_version=1)
        self.assertEqual(fake_confirmation["status"], "rejected")
        opid = "idempotent-fault-op"
        payload = {"asset_id":"fst-1", "asset_version":1, "category":"Elektrik", "description":"Kabel locker, Prüfung nötig.", "priority":"NORMAL", "shift":"Früh"}
        first = prod.op("fault.create", "fault-idempotent", payload, asset_version=1, op_id=opid)
        second = prod.op("fault.create", "fault-idempotent", payload, asset_version=1, op_id=opid)
        self.assertEqual(first, second)
        duplicate = prod.op("fault.create", "fault-duplicate", payload, asset_version=2)
        self.assertEqual(duplicate["status"], "conflict")
        cross_account = tech.op("fault.accept", "fault-idempotent", {}, base_version=1, asset_version=2, op_id=opid)
        self.assertEqual(cross_account["status"], "rejected")
        accepted = tech.op("fault.accept", "fault-idempotent", {}, base_version=1, asset_version=2)
        self.assertEqual(accepted["status"], "accepted")
        incomplete_release = tech.op("fault.release", "fault-idempotent", {"repair_note":"Prüfung", "technical_test":"Test"}, base_version=2, asset_version=3)
        self.assertEqual(incomplete_release["status"], "rejected")
        stale = tech.op("fault.diagnose", "fault-idempotent", {"diagnosis":"D1", "cause":"C", "measures":"M", "parts":"", "comment":""}, base_version=1)
        self.assertEqual(stale["status"], "conflict")
        snapshot = self.snapshot(lead)
        self.assertEqual(len([f for f in snapshot["faults"] if f["asset_id"]=="fst-1"]), 1)

    def test_parallel_asset_updates_have_one_winner(self):
        lead1 = self.client("schicht", "User-Start-Password-42")
        lead2 = self.client("schicht", "User-Start-Password-42")
        def update(client, target, oid):
            return client.op("asset.status", "fst-1", {"status":target,"initial_confirmed":True,"shift":"Früh"}, base_version=1, op_id=oid)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            a=pool.submit(update,lead1,"START_READY","parallel-a")
            b=pool.submit(update,lead2,"CLEANING","parallel-b")
            results=[a.result(),b.result()]
        self.assertEqual(sorted(r["status"] for r in results), ["accepted","conflict"])

    def test_note_lifecycle_and_material_sequence(self):
        prod = self.client("production", "User-Start-Password-42")
        lead = self.client("schicht", "User-Start-Password-42")
        tech = self.client("technik", "User-Start-Password-42")
        note = prod.op("note.create", "note-test", {"title":"Übergabe", "category":"Sonstiges", "description":"Eintrag bleibt über Schichtwechsel offen.", "asset_id":"fst-1", "area":"Linie", "priority":"NORMAL", "shift":"Spät"})
        self.assertEqual(note["status"], "accepted")
        denied = prod.op("note.complete", "note-test", {}, base_version=1)
        self.assertEqual(denied["status"], "denied")
        assumed = lead.op("note.assume", "note-test", {}, base_version=1)
        self.assertEqual(assumed["status"], "accepted")
        completed = lead.op("note.complete", "note-test", {}, base_version=2)
        self.assertEqual(completed["status"], "accepted")
        request = prod.op("material.create", "material-seq", {"name":"Etikettenrolle", "category":"Etiketten", "quantity":"", "unit":"", "asset_id":None, "area":"", "description":"", "shift":"Nacht"})
        self.assertEqual(request["status"], "accepted")
        skip = lead.op("material.status", "material-seq", {"status":"ORDERED"}, base_version=1)
        self.assertEqual(skip["status"], "rejected")
        statuses = ["CHECKED", "ORDERED", "DELIVERED", "DONE"]
        for version, target in enumerate(statuses, start=1):
            self.assertEqual(lead.op("material.status", "material-seq", {"status":target}, base_version=version)["status"], "accepted")
        tech_status, _, _ = tech.request("GET", "/api/archive")
        self.assertEqual(tech_status, 200)
        archive_status, archive, _ = lead.request("GET", "/api/archive?shift=Nacht")
        self.assertEqual(archive_status, 200)
        self.assertTrue(any(x["id"]=="material-seq" for x in archive["items"]))

    def test_user_admin_update_and_password_reset(self):
        admin = self.client()
        created = admin.op("admin.user.create", "user-password-test", {"username":"resetme", "display_name":"Reset Person", "role":"PRODUCTION", "password":"Initial-Password-543"})
        self.assertEqual(created["status"], "accepted")
        users = self.snapshot(admin)["users"]
        target = next(u for u in users if u["username"]=="resetme")
        invalid_active = admin.op("admin.user.update", target["id"], {"active":"false"}, base_version=target["version"])
        self.assertEqual(invalid_active["status"], "rejected")
        reset = admin.op("admin.user.update", target["id"], {"password":"Reset-Password-987"}, base_version=target["version"])
        self.assertEqual(reset["status"], "accepted")
        self.assertTrue(next(u for u in self.snapshot(admin)["users"] if u["id"]==target["id"])["must_change"])
        reset_client = self.client("resetme", "Reset-Password-987")
        self.assertTrue(reset_client.user["must_change"])

    def test_help_links_are_admin_managed_https_and_visible_by_role(self):
        admin = self.client()
        production = self.client("production", "User-Start-Password-42")
        created = admin.op("admin.help_link.create", "help-link-1", {
            "title":"Schichtleitfaden", "description":"Lokale Kurzanleitung.", "url":"https://example.org/shift-guide"
        })
        self.assertEqual(created["status"], "accepted")
        admin_link = next(link for link in self.snapshot(admin)["help_links"] if link["id"]=="help-link-1")
        self.assertTrue(admin_link["active"])
        self.assertEqual([link["id"] for link in self.snapshot(production)["help_links"]], ["help-link-1"])
        duplicate = admin.op("admin.help_link.create", "help-link-1", {
            "title":"Doppelte ID", "description":"", "url":"https://example.org/duplicate"
        })
        self.assertEqual(duplicate["status"], "rejected")
        denied = production.op("admin.help_link.create", "help-link-forbidden", {
            "title":"Unberechtigt", "description":"", "url":"https://example.org/other"
        })
        self.assertEqual(denied["status"], "denied")
        disabled = admin.op("admin.help_link.active", "help-link-1", {"active":False}, base_version=admin_link["version"])
        self.assertEqual(disabled["status"], "accepted")
        self.assertEqual(self.snapshot(production)["help_links"], [])
        inactive = next(link for link in self.snapshot(admin)["help_links"] if link["id"]=="help-link-1")
        self.assertFalse(inactive["active"])

    def test_help_link_rejects_non_https_credentials_and_ambiguous_urls(self):
        admin = self.client()
        invalid_urls = [
            "http://example.org/help", "javascript:alert(1)", "https:///missing-host",
            "https://user:secret@example.org/help", "https://example.org\\@evil.test",
            "https://example.org/path with space", "https://example.org/%0aheader"
        ]
        for index, url in enumerate(invalid_urls):
            result = admin.op("admin.help_link.create", f"invalid-link-{index}", {
                "title":"Ungültiger Link", "description":"", "url":url
            })
            self.assertEqual(result["status"], "rejected", url)
        self.assertEqual(self.snapshot(admin)["help_links"], [])

    def test_last_active_administrator_cannot_be_removed_by_role_change(self):
        admin = self.client()
        created = admin.op("admin.user.create", "second-admin", {"username":"secondadmin", "display_name":"Zweiter Admin", "role":"ADMINISTRATOR", "password":"Admin-Start-Password-98"})
        self.assertEqual(created["status"], "accepted")
        second = next(u for u in self.snapshot(admin)["users"] if u["username"]=="secondadmin")
        demote = admin.op("admin.user.update", second["id"], {"role":"PRODUCTION"}, base_version=second["version"])
        self.assertEqual(demote["status"], "accepted")
        primary = next(u for u in self.snapshot(admin)["users"] if u["username"]=="admin")
        last = admin.op("admin.user.update", primary["id"], {"role":"PRODUCTION"}, base_version=primary["version"])
        self.assertEqual(last["status"], "rejected")

    def test_bad_photo_and_invalid_fields_are_rejected(self):
        prod = self.client("production", "User-Start-Password-42")
        bad_photo = "data:image/png;base64," + base64.b64encode(b"not-a-png").decode()
        result = prod.op("fault.create", "bad-photo-fault", {"asset_id":"fst-1", "asset_version":1, "category":"Test", "description":"Fehlerhafte Bildsignatur", "priority":"NORMAL", "shift":"Früh", "photo_data":bad_photo}, asset_version=1)
        self.assertEqual(result["status"], "rejected")
        bad_shift = prod.op("fault.create", "bad-shift-fault", {"asset_id":"fst-1", "asset_version":1, "category":"Test", "description":"Ungültige Schicht", "priority":"NORMAL", "shift":"Mitternacht"}, asset_version=1)
        self.assertEqual(bad_shift["status"], "rejected")
        bad_priority = prod.op("fault.create", "bad-priority-fault", {"asset_id":"fst-1", "asset_version":1, "category":"Test", "description":"Ungültige Priorität", "priority":"KRITISCH", "shift":"Früh"}, asset_version=1)
        self.assertEqual(bad_priority["status"], "rejected")

    def test_csrf_origin_and_login_lockout(self):
        admin = self.client()
        status, _, _ = admin.request("POST", "/api/notifications/read", {"ids":[]}, csrf=False)
        self.assertEqual(status, 403)
        status, _, _ = admin.request("POST", "/api/notifications/read", {"ids":[]}, origin="https://attacker.invalid")
        self.assertEqual(status, 403)
        lock_client = ApiClient(self.httpd.server_address[1])
        for _ in range(5):
            status, _, _ = lock_client.request("POST", "/api/login", {"username":"production", "password":"Wrong-Password"}, csrf=False)
            self.assertEqual(status, 401)
        status, data, _ = lock_client.request("POST", "/api/login", {"username":"production", "password":"User-Start-Password-42"}, csrf=False)
        self.assertEqual(status, 423)

    def test_session_survives_server_restart(self):
        admin = self.client()
        before = admin.request("GET", "/api/me")[1]["user"]
        self._stop_server()
        self._start_server()
        admin.port = self.httpd.server_address[1]
        status, data, _ = admin.request("GET", "/api/me")
        self.assertEqual(status, 200)
        self.assertEqual(data["user"]["id"], before["id"])

    def test_backup_restore_data_match_and_bad_backup_rejected(self):
        admin = self.client()
        prod = self.client("production", "User-Start-Password-42")
        self.fault_report(prod)
        expected = self.snapshot(admin)
        status, backup, headers = admin.request("GET", "/api/admin/backup")
        self.assertEqual(status, 200)
        self.assertIsInstance(backup, bytes)
        with zipfile.ZipFile(BytesIO(backup)) as z:
            db_bytes=z.read("works.sqlite3")
            manifest=json.loads(z.read("manifest.json"))
        self.assertEqual(manifest["integrity_check"], "ok")
        # Corrupt database bytes while retaining the original manifest hash.
        bad_io=BytesIO()
        with zipfile.ZipFile(bad_io,"w",zipfile.ZIP_DEFLATED) as z:
            z.writestr("works.sqlite3",db_bytes[:-1]+bytes([db_bytes[-1]^1]))
            z.writestr("manifest.json",json.dumps(manifest))
        status, _, _ = admin.request("POST", "/api/admin/restore", raw=bad_io.getvalue(), headers={"Content-Type":"application/zip","X-Works-Confirm":"RESTORE"})
        self.assertEqual(status, 400)
        rename = admin.op("admin.asset.update", "fst-1", {"name":"FST 1 changed"}, base_version=2)
        self.assertEqual(rename["status"], "accepted")
        status, result, _ = admin.request("POST", "/api/admin/restore", raw=backup, headers={"Content-Type":"application/zip","X-Works-Confirm":"RESTORE"})
        self.assertEqual(status, 200, result)
        self.assertEqual(admin.request("GET", "/api/me")[0], 401)
        admin2 = self.client()
        actual = self.snapshot(admin2)
        for key in ("assets","faults","notes","materials","users","history"):
            self.assertEqual(actual[key], expected[key], key)
        self.assertEqual(result["ok"], True)
        # Schema-3 backups remain restorable; the additive link table is migrated locally.
        old_path = Path(self.tmp.name) / "schema3.sqlite3"
        old_path.write_bytes(db_bytes)
        old_db = sqlite3.connect(old_path)
        try:
            old_db.execute("DROP TABLE help_links")
            old_db.execute("PRAGMA user_version=3")
            old_db.commit()
        finally:
            old_db.close()
        old_db_bytes = old_path.read_bytes()
        old_manifest = dict(manifest)
        old_manifest.update({"version":"1.0.0","schema":3,"size":len(old_db_bytes),"sha256":hashlib.sha256(old_db_bytes).hexdigest()})
        old_package = BytesIO()
        with zipfile.ZipFile(old_package,"w",zipfile.ZIP_DEFLATED) as z:
            z.writestr("works.sqlite3",old_db_bytes)
            z.writestr("manifest.json",json.dumps(old_manifest))
        status, migrated, _ = admin2.request("POST", "/api/admin/restore", raw=old_package.getvalue(), headers={"Content-Type":"application/zip","X-Works-Confirm":"RESTORE"})
        self.assertEqual(status, 200, migrated)
        self.assertEqual(migrated["restored_schema"], 4)
        admin3 = self.client()
        self.assertEqual(self.snapshot(admin3)["help_links"], [])
        with self.store.connect() as check:
            self.assertEqual(check.execute("PRAGMA user_version").fetchone()[0], 4)

if __name__ == "__main__":
    unittest.main(verbosity=2)
