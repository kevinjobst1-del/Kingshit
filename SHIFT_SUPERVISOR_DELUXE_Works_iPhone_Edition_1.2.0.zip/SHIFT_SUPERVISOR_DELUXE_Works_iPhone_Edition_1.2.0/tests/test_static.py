"""Static scope and web-app shell checks; not browser/device execution."""
import json
import re
import sqlite3
import unittest
from pathlib import Path

from server.works_server import SCHEMA

ROOT = Path(__file__).resolve().parents[1]

class StaticChecks(unittest.TestCase):
    def test_schema_contains_only_communication_workflow_tables(self):
        db = sqlite3.connect(":memory:")
        try:
            db.executescript(SCHEMA)
            tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
            self.assertEqual(tables, {"users","assets","faults","forecasts","shift_notes","materials","audit_events","sync_results","sessions","notifications","login_failures","help_links"})
            columns = {table: {row[1].lower() for row in db.execute(f"PRAGMA table_info({table})")} for table in tables}
            forbidden = {"oee","kpi","production_report","planned_output","actual_output","order_id","work_hours","stock_balance","performance_score","erp_reference"}
            all_columns = set().union(*columns.values())
            self.assertFalse(forbidden & all_columns)
            self.assertEqual({table for table, names in columns.items() if "quantity" in names}, {"materials"})
        finally:
            db.close()

    def test_mobile_navigation_reaches_every_role_area(self):
        app = (ROOT / "app/js/app.js").read_text(encoding="utf-8")
        self.assertIn("mobilePrimary.map(navButton)", app)
        self.assertIn("mobileMore.map(navButton)", app)
        self.assertIn('data-action="mobile-more"', app)
        self.assertIn('aria-expanded="${state.mobileMoreOpen?', app)
        self.assertIn('aria-controls="mobile-more-panel"', app)
        self.assertNotIn("top5=items.filter", app)

    def test_forms_progressively_disclose_optional_fields_and_require_choices(self):
        app = (ROOT / "app/js/app.js").read_text(encoding="utf-8")
        self.assertGreaterEqual(app.count('<details class="field full optional-fields">'), 3)
        self.assertIn('Anlage auswählen …', app)
        self.assertIn('Kategorie auswählen …', app)
        self.assertIn('Status auswählen …', app)

    def test_external_links_are_click_only_https_and_no_referrer(self):
        app = (ROOT / "app/js/app.js").read_text(encoding="utf-8")
        self.assertIn('href="${esc(link.url)}"', app)
        self.assertIn('target="_blank"', app)
        self.assertIn('rel="noopener noreferrer"', app)
        self.assertIn('referrerpolicy="no-referrer"', app)
        self.assertIn("Nur HTTPS-URLs ohne Zugangsdaten", (ROOT / "server/works_server.py").read_text(encoding="utf-8"))
        self.assertNotRegex(app, r'href=["\']https?://')
        sw = (ROOT / "app/sw.js").read_text(encoding="utf-8")
        self.assertIn("if(url.origin!==self.location.origin||url.pathname.startsWith('/api/'))return;", sw)

    def test_ios_pwa_metadata_and_server_deployment_profile(self):
        index = (ROOT / "app/index.html").read_text(encoding="utf-8")
        manifest = json.loads((ROOT / "app/manifest.webmanifest").read_text(encoding="utf-8"))
        self.assertIn('apple-mobile-web-app-capable', index)
        self.assertIn('apple-touch-icon', index)
        self.assertEqual(manifest["display"], "standalone")
        self.assertEqual(manifest["lang"], "de-DE")
        install = (ROOT / "deploy/install-ubuntu.sh").read_text(encoding="utf-8")
        serve = (ROOT / "deploy/setup-tailscale-serve.sh").read_text(encoding="utf-8")
        self.assertIn("WORKS_HOST=127.0.0.1", install)
        self.assertIn("WORKS_SECURE_COOKIE=1", install)
        self.assertIn("tailscale serve --bg 8080", serve)
        self.assertNotIn("tailscale funnel", serve.lower())
        self.assertIn("WORKS_PUBLIC_ORIGIN", serve)

    def test_hosted_runtime_uses_platform_port_and_https_origin(self):
        server = (ROOT / "server/works_server.py").read_text(encoding="utf-8")
        self.assertIn('os.environ.get("WORKS_PORT") or os.environ.get("PORT")', server)
        self.assertIn('os.environ.get("RENDER_EXTERNAL_HOSTNAME"', server)
        self.assertIn('os.environ.get("RAILWAY_PUBLIC_DOMAIN"', server)
        self.assertIn("WORKS_PUBLIC_ORIGIN", server)
        self.assertIn("WORKS_SECURE_COOKIE", server)

    def test_render_deployment_has_persistent_single_instance_and_drops_root(self):
        import yaml
        blueprint = yaml.safe_load((ROOT / "render.yaml").read_text(encoding="utf-8"))
        services = blueprint["services"]
        self.assertEqual(len(services), 1)
        service = services[0]
        self.assertEqual(service["type"], "web")
        self.assertEqual(service["runtime"], "docker")
        self.assertEqual(service["numInstances"], 1)
        self.assertEqual(service["healthCheckPath"], "/api/health")
        self.assertEqual(service["disk"]["mountPath"], "/var/lib/works")
        dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
        entrypoint = (ROOT / "docker/entrypoint.sh").read_text(encoding="utf-8")
        self.assertIn("gosu", dockerfile)
        self.assertIn("exec gosu works", entrypoint)
        self.assertIn("WORKS_DATA_DIR=/var/lib/works", dockerfile)

    def test_manifest_and_service_worker_cache_policy(self):
        manifest = json.loads((ROOT / "app/manifest.webmanifest").read_text(encoding="utf-8"))
        self.assertEqual(manifest["lang"], "de-DE")
        self.assertEqual(manifest["display"], "standalone")
        sw = (ROOT / "app/sw.js").read_text(encoding="utf-8")
        self.assertIn("url.pathname.startsWith('/api/')", sw)
        self.assertIn("ssd-works-static-1.2.0-v1", sw)
        app = (ROOT / "app/js/app.js").read_text(encoding="utf-8")
        store = (ROOT / "app/js/store.js").read_text(encoding="utf-8")
        self.assertIn("owner_id===state.me.id", app)
        self.assertIn("maxBodyBytes=1750000", app)
        self.assertIn("local_created_at||''", store)

if __name__ == "__main__":
    unittest.main(verbosity=2)
