#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export WORKS_HOST="${WORKS_HOST:-127.0.0.1}"
export WORKS_PORT="${WORKS_PORT:-8080}"
export WORKS_DATA_DIR="${WORKS_DATA_DIR:-${ROOT}/var}"
exec python3 "${ROOT}/server/works_server.py" serve
