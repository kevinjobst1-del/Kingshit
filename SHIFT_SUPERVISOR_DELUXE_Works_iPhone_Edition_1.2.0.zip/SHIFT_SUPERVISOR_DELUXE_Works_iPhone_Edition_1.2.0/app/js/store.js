'use strict';
(function(global){
  const DB_NAME='ssd-works-offline',DB_VERSION=1,STORE='kv',QUEUE='queue';let opening=null;
  function open(){if(opening)return opening;opening=new Promise((resolve,reject)=>{
    if(!global.indexedDB){reject(new Error('Lokaler Offline-Speicher nicht verfügbar.'));return;}
    const req=global.indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE);if(!db.objectStoreNames.contains(QUEUE))db.createObjectStore(QUEUE,{keyPath:'op_id'});};
    req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error('IndexedDB konnte nicht geöffnet werden.'));req.onblocked=()=>reject(new Error('Lokaler Speicher ist in einem anderen Fenster blockiert.'));
  });return opening;}
  async function request(storeName,mode,action){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(storeName,mode),os=tx.objectStore(storeName);let result;try{result=action(os);}catch(e){reject(e);return;}tx.oncomplete=()=>resolve(result&&typeof result.then==='function'?result:result);tx.onerror=()=>reject(tx.error||new Error('Lokaler Speichervorgang fehlgeschlagen.'));tx.onabort=()=>reject(tx.error||new Error('Lokaler Speichervorgang abgebrochen.'));});}
  function reqValue(req){return new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error('IndexedDB-Lesevorgang fehlgeschlagen.'));});}
  global.WorksLocal={
    async get(key){const db=await open();return reqValue(db.transaction(STORE,'readonly').objectStore(STORE).get(key));},
    async set(key,value){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(value,key);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||new Error('Lokales Speichern fehlgeschlagen.'));tx.onabort=()=>reject(tx.error||new Error('Lokales Speichern abgebrochen.'));});},
    async remove(key){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).delete(key);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||new Error('Lokales Löschen fehlgeschlagen.'));});},
    async queueAdd(operation){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(QUEUE,'readwrite');tx.objectStore(QUEUE).put(operation);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||new Error('Offline-Vorgang konnte nicht gespeichert werden.'));tx.onabort=()=>reject(tx.error||new Error('Offline-Vorgang wurde abgebrochen.'));});},
    async queueAll(){const db=await open();const items=await reqValue(db.transaction(QUEUE,'readonly').objectStore(QUEUE).getAll());return (items||[]).sort((a,b)=>String(a.local_created_at||'').localeCompare(String(b.local_created_at||''))||String(a.op_id).localeCompare(String(b.op_id)));},
    async queueDelete(opId){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(QUEUE,'readwrite');tx.objectStore(QUEUE).delete(opId);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||new Error('Offline-Vorgang konnte nicht entfernt werden.'));});},
    async queueUpdate(operation){return this.queueAdd(operation);},
    async clearQueue(){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(QUEUE,'readwrite');tx.objectStore(QUEUE).clear();tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||new Error('Offline-Warteschlange konnte nicht geleert werden.'));});}
  };
})(window);
