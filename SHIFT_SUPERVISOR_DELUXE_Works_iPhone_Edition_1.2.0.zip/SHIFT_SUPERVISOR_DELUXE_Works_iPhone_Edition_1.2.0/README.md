# SHIFT SUPERVISOR DELUXE – Works Edition 1.2.0

**Status: DEPLOYMENT-PAKET VORBEREITET, NOCH NICHT ONLINE BEREITGESTELLT.** Version 1.2.0 ergänzt ein Docker-Image und einen Render-Blueprint für eine einzelne Cloud-Instanz mit persistentem Datenträger. Alternativ bleibt die private Ubuntu-/Debian-Installation mit Tailscale Serve enthalten. Es wurde kein Cloud-Konto autorisiert, kein Server angelegt und kein echtes iPhone angeschlossen. Daher ist die Software weiterhin NICHT READY FOR PILOT.

## Zweck

Works ist Organisations- und Kommunikationssoftware für den Schichtbetrieb. Enthalten sind Anlagenstatus, Technikmeldungen, Schichtbesonderheiten, Schichtübergabe, Materialbedarf, Archiv, Benachrichtigungen, Benutzerkonten und Administration.

Nicht enthalten sind KPI/OEE, Produktionsmengen oder -berichte, Auftragsverwaltung, Produktionsplanung, Zeiterfassung, Lagerverwaltung, ERP, Leistungsbewertung oder komplexes QM. Materialmengen sind ausschließlich Teil einer Materialbedarfs-Meldung.

## Mehrbenutzer- und Serverarchitektur

- Zentraler Python-HTTP-Server (Python 3.10+, Standardbibliothek) mit mehreren HTTP-Threads.
- Zentrale SQLite-Datenbank im WAL-Modus; eine einzelne schreibende Serverinstanz.
- Server-seitige Rollen: Administrator, Schichtleiter, Technik und Produktion.
- Serverseitige Passwortprüfung (scrypt), Sessions, CSRF-/Origin-Prüfung, Login-Lockout und Versionskonflikte.
- Mobile-first PWA für Safari/iPhone, iPad und Desktop-Browser.
- Offline-Warteschlange in IndexedDB; API-Antworten werden nicht durch den Service Worker gecacht.

## Bereitstellung für iPhone und Mehrbenutzerbetrieb

**Cloud-Weg (für einen Start ohne eigenen Windows-PC):** Das Paket enthält `Dockerfile` und `render.yaml` für Render in Frankfurt. Die Cloud stellt eine HTTPS-Adresse bereit; eine einzelne Instanz schreibt die zentrale SQLite-Datenbank auf einen persistenten Datenträger unter `/var/lib/works`. Die erste Einrichtung benötigt ein Render-Konto und ein Git-Repository, auf das Render zugreifen kann. Die Cloud-Konfiguration ist vorbereitet, aber noch nicht auf ein Konto ausgerollt.

1. Den vollständigen Projektordner in ein privates Git-Repository übernehmen.
2. In Render ein neues Blueprint aus diesem Repository anlegen und `render.yaml` prüfen.
3. Den kostenpflichtigen Starter-Webdienst mit persistentem Datenträger `/var/lib/works` bereitstellen.
4. Nach erfolgreichem Healthcheck den ersten Administrator im Render-Service-Shell anlegen:
   `gosu works python3 /app/server/works_server.py bootstrap-admin`
5. Den erzeugten HTTPS-Link in Safari auf dem iPhone öffnen und „Zum Home-Bildschirm“ hinzufügen.

Details: `docs/CLOUD-DEPLOY-RENDER.md`. Diese Variante ist internet-erreichbar; nur mit erfundenen Testdaten einsetzen, bis IT/Security/Datenschutz sie freigegeben hat. Render-Persistent-Disks sind für eine einzelne Instanz vorgesehen und verhindern horizontales Skalieren; das passt zur SQLite-Einzelinstanz-Architektur.

**Privater Weg (VPS + Tailscale):** Für einen privaten Testzugang wird Tailscale Serve verwendet. Der Works-Server lauscht ausschließlich auf `127.0.0.1:8080`. Tailscale stellt davor eine HTTPS-Adresse bereit, die nur im angemeldeten Tailscale-Netz erreichbar ist. **Tailscale Funnel wird nicht verwendet.** Jedes zugelassene iPhone benötigt die Tailscale-App und eine Berechtigung im Tailnet.

Die Bereitstellungsskripte sind für Ubuntu 22.04+ und Debian 12+ vorbereitet:

1. ZIP vollständig entpacken.
2. Im Projektverzeichnis `sudo ./deploy/install-ubuntu.sh` ausführen.
3. Tailscale installieren und den Server mit dem vorgesehenen Tailnet verbinden.
4. `sudo /opt/shift-supervisor-works/deploy/setup-tailscale-serve.sh` ausführen.
5. `sudo /opt/shift-supervisor-works/deploy/bootstrap-admin.sh` ausführen und das erste Administratorkonto interaktiv anlegen.
6. Auf dem iPhone Tailscale verbinden, die angezeigte HTTPS-Adresse in Safari öffnen und „Zum Home-Bildschirm“ hinzufügen.

Die vollständige Anleitung ist `docs/IPHONE-INSTALLATION.md`.

## Start / lokale technische Prüfung

Python 3.10 oder neuer:

```bash
python3 server/works_server.py init-db
python3 server/works_server.py bootstrap-admin
python3 server/works_server.py serve
```

Das ist ausschließlich lokaler Entwicklungstest auf `127.0.0.1:8080`, nicht für den Netzwerkbetrieb. Für Netzwerkzugriff ist ein freigegebener HTTPS-Endpunkt zwingend.

## Prüfungen

```bash
python3 -m unittest discover -s tests -v
python3 -m py_compile server/works_server.py tests/test_integration.py
node --check app/js/app.js
node --check app/js/store.js
node --check app/sw.js
python3 -m json.tool app/manifest.webmanifest
```

## Sicherheitsgrenzen und Freigabestatus

- Die Works-Anwendung stellt selbst kein TLS bereit. HTTPS kommt von Tailscale Serve (privater Test) oder einem durch IT freigegebenen Reverse Proxy.
- SQLite-Datei und In-App-Backups sind nicht anwendungsverschlüsselt. Server-Datenträger und externe Backup-Ablage müssen durch IT verschlüsselt werden.
- IndexedDB-Offlinedaten sind nicht anwendungsverschlüsselt. Gerätecode, Geräteverwaltung und Benutzerprofil-Schutz sind erforderlich.
- Tailscale-Zugriffskontrollen müssen auf ausdrücklich zugelassene Benutzer/Geräte begrenzt werden. Der Works-Login bleibt zusätzlich erforderlich.
- Eine einzelne Serverinstanz; keine horizontale Skalierung, Hochverfügbarkeit oder Leistungszusage.
- Benachrichtigungen per In-App-Polling, kein Push.
- Kein nativer iOS-Build und noch kein echter iPhone-/Safari-Gerätetest.
- Kein Penetrationstest, Datenschutzgutachten, IT-Freigabe oder Pilot-Go.

**Vor realen Betriebsdaten** sind IT, Datenschutz und Betriebsverantwortliche einzubeziehen. Der aktuelle Status bleibt **NICHT READY FOR PILOT**.

## Projektstruktur

- `app/` – PWA, Manifest, Service Worker und mobile Oberfläche
- `server/works_server.py` – API, Rollen, Anmeldung, Datenbank und Workflows
- `deploy/` – Ubuntu/Debian-Installation, Tailscale Serve, Admin-Bootstrap und Statusprüfung
- `docker/`, `Dockerfile`, `render.yaml` – unprivilegiertes Cloud-Container-Profil mit persistentem Datenvolume
- `docs/` – iPhone-Installation, Architektur, Betrieb, Backup/Restore, Tests und Abnahme
- `tests/` – HTTP-Integrationstests und statische Prüfungen
