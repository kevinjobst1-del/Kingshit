#!/usr/bin/env bash
# Publishes the local Works server only inside the authenticated Tailscale tailnet.
set -Eeuo pipefail
SERVICE_NAME="shift-supervisor-works"
ENV_FILE="/etc/works/works.env"

fail() { echo "FEHLER: $*" >&2; exit 1; }
[[ "${EUID}" -eq 0 ]] || fail "Bitte mit sudo ausführen."
command -v tailscale >/dev/null 2>&1 || fail "Tailscale ist nicht installiert. Siehe docs/IPHONE-INSTALLATION.md."
[[ -f "${ENV_FILE}" ]] || fail "${ENV_FILE} fehlt. Zuerst deploy/install-ubuntu.sh ausführen."

STATUS_JSON="$(tailscale status --json 2>/dev/null)" || fail "Tailscale ist nicht angemeldet. Erst 'sudo tailscale up' ausführen."
DNS_NAME="$(printf '%s' "${STATUS_JSON}" | python3 -c 'import json,sys; d=json.load(sys.stdin); print((d.get("Self",{}).get("DNSName") or "").rstrip("."))')"
[[ -n "${DNS_NAME}" ]] || fail "Tailscale-DNS-Name fehlt. MagicDNS/HTTPS in der Tailnet-Konfiguration prüfen."
[[ "${DNS_NAME}" == *.ts.net ]] || fail "Unerwarteter Tailscale-DNS-Name. Erwartet wird ein MagicDNS-Name unter .ts.net, gefunden: ${DNS_NAME}"

TMP="$(mktemp)"
trap 'rm -f "${TMP}"' EXIT
awk '!/^WORKS_PUBLIC_ORIGIN=/' "${ENV_FILE}" > "${TMP}"
printf 'WORKS_PUBLIC_ORIGIN=https://%s\n' "${DNS_NAME}" >> "${TMP}"
install -o root -g root -m 0600 "${TMP}" "${ENV_FILE}"

systemctl restart "${SERVICE_NAME}.service"
# Serve terminates HTTPS and forwards privately to the loopback-only application port.
tailscale serve --bg 8080

URL="https://${DNS_NAME}"
echo
printf 'Private Works-Adresse: %s\n' "${URL}"
echo "Serve-Status:"
tailscale serve status

echo
echo "WICHTIG: Zugriff nur für ausdrücklich berechtigte Tailnet-Geräte erlauben."
echo "Auf jedem iPhone Tailscale verbinden, dann die Adresse in Safari öffnen."
