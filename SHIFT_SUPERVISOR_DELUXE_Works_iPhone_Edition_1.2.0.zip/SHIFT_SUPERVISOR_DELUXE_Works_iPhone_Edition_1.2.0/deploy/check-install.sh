#!/usr/bin/env bash
set -Eeuo pipefail
SERVICE_NAME="shift-supervisor-works"

systemctl is-active --quiet "${SERVICE_NAME}.service" || { echo "Dienst ist nicht aktiv." >&2; systemctl status "${SERVICE_NAME}.service" --no-pager || true; exit 1; }
if command -v curl >/dev/null 2>&1; then
  curl --fail --silent --show-error http://127.0.0.1:8080/api/health
  echo
else
  echo "curl fehlt; Dienststatus ist aktiv, HTTP-Healthcheck wurde übersprungen."
fi
stat -c 'Datenverzeichnis: %A %U:%G %n' /var/lib/works
stat -c 'Datenbank: %A %U:%G %n' /var/lib/works/works.sqlite3 2>/dev/null || true
