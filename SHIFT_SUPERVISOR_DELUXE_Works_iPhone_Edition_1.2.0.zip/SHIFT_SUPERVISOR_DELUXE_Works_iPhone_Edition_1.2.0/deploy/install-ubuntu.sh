#!/usr/bin/env bash
# Initial installation for Ubuntu 22.04+/Debian 12+.
# Run from the extracted project directory: sudo ./deploy/install-ubuntu.sh
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="/opt/shift-supervisor-works"
DATA_DIR="/var/lib/works"
ETC_DIR="/etc/works"
SERVICE_NAME="shift-supervisor-works"

fail() { echo "FEHLER: $*" >&2; exit 1; }

[[ "${EUID}" -eq 0 ]] || fail "Bitte mit sudo ausführen."
[[ -f "${SOURCE_DIR}/server/works_server.py" && -f "${SOURCE_DIR}/app/index.html" ]] || fail "Projektwurzel nicht erkannt. ZIP vollständig entpacken und Script aus deploy/ ausführen."

if [[ -r /etc/os-release ]]; then . /etc/os-release; else fail "/etc/os-release fehlt."; fi
case "${ID:-}" in
  ubuntu|debian) ;;
  *) fail "Unterstützt werden Ubuntu und Debian. Erkannt: ${ID:-unbekannt}" ;;
esac

command -v python3 >/dev/null 2>&1 || fail "Python 3 fehlt. Bitte Python 3.10 oder neuer über die Distribution installieren."
PY_VERSION="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' || fail "Python ${PY_VERSION} ist zu alt. Benötigt wird Python 3.10 oder neuer."

[[ ! -e "${APP_DIR}" ]] || fail "${APP_DIR} existiert bereits. Keine automatische Überschreibung; erst sichern und manuell prüfen."

if ! getent group works >/dev/null; then groupadd --system works; fi
if ! id works >/dev/null 2>&1; then
  useradd --system --gid works --home-dir "${DATA_DIR}" --create-home --shell /usr/sbin/nologin works
fi

install -d -o root -g root -m 0755 "${APP_DIR}"
cp -a "${SOURCE_DIR}/." "${APP_DIR}/"
chown -R root:root "${APP_DIR}"
find "${APP_DIR}" -type d -exec chmod 0755 {} +
find "${APP_DIR}" -type f -exec chmod 0644 {} +
chmod 0755 "${APP_DIR}"/deploy/*.sh
install -d -o works -g works -m 0700 "${DATA_DIR}" "${DATA_DIR}/backups"
install -d -o root -g root -m 0750 "${ETC_DIR}"

if [[ ! -f "${ETC_DIR}/works.env" ]]; then
  cat > "${ETC_DIR}/works.env" <<'ENV'
WORKS_HOST=127.0.0.1
WORKS_PORT=8080
WORKS_DATA_DIR=/var/lib/works
WORKS_SECURE_COOKIE=1
WORKS_PUBLIC_ORIGIN=
ENV
  chown root:root "${ETC_DIR}/works.env"
  chmod 0600 "${ETC_DIR}/works.env"
fi

cat > "/etc/systemd/system/${SERVICE_NAME}.service" <<'UNIT'
[Unit]
Description=SHIFT SUPERVISOR DELUXE Works Edition
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=works
Group=works
WorkingDirectory=/opt/shift-supervisor-works
EnvironmentFile=/etc/works/works.env
ExecStart=/usr/bin/python3 /opt/shift-supervisor-works/server/works_server.py serve
Restart=on-failure
RestartSec=5
TimeoutStopSec=20
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
LockPersonality=true
ReadWritePaths=/var/lib/works

[Install]
WantedBy=multi-user.target
UNIT

# Initialize through the dedicated unprivileged service identity.
runuser -u works -- env WORKS_DATA_DIR="${DATA_DIR}" python3 "${APP_DIR}/server/works_server.py" init-db
systemctl daemon-reload
systemctl enable --now "${SERVICE_NAME}.service"

cat <<'MSG'

Installation der Serverdateien abgeschlossen.

Nächste Schritte:
1. Tailscale gemäß docs/IPHONE-INSTALLATION.md installieren und den Server anmelden.
2. Danach als root ausführen:
     sudo /opt/shift-supervisor-works/deploy/setup-tailscale-serve.sh
3. Administrator einmalig anlegen:
     sudo /opt/shift-supervisor-works/deploy/bootstrap-admin.sh
4. Die HTTPS-Adresse auf dem iPhone in Safari öffnen.

Der Server lauscht nur auf 127.0.0.1:8080. Der Anwendungsport wird nicht direkt im Netzwerk freigegeben.
Bis zu IT-/Datenschutzfreigabe ausschließlich mit Testdaten arbeiten.
MSG
