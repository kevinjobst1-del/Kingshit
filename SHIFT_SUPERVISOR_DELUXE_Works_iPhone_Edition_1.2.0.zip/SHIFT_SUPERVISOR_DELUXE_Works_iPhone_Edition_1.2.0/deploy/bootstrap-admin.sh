#!/usr/bin/env bash
# Creates the first Works administrator interactively; no default credentials.
set -Eeuo pipefail
[[ "${EUID}" -eq 0 ]] || { echo "Bitte mit sudo ausführen." >&2; exit 1; }
runuser -u works -- env WORKS_DATA_DIR=/var/lib/works python3 /opt/shift-supervisor-works/server/works_server.py bootstrap-admin
