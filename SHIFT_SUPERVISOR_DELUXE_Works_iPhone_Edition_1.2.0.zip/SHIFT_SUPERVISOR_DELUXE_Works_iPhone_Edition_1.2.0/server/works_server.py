#!/usr/bin/env python3
"""SHIFT SUPERVISOR DELUXE Works Edition 1.2.0 server.
Standard-library only; deploy behind an IT-approved HTTPS reverse proxy.
"""
from __future__ import annotations
import argparse, base64, hashlib, hmac, io, json, os, re, secrets, shutil, sqlite3, sys, tempfile, threading, time, uuid, zipfile
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from socketserver import ThreadingMixIn
from urllib.parse import parse_qs, unquote, urlsplit

APP_VERSION = "1.2.0"
SCHEMA_VERSION = 4
ROLES = {"ADMINISTRATOR", "SHIFT_LEADER", "TECHNICIAN", "PRODUCTION"}
ROLE_LABELS = {"ADMINISTRATOR":"Administrator", "SHIFT_LEADER":"Schichtleiter", "TECHNICIAN":"Technik", "PRODUCTION":"Produktion"}
SHIFTS = {"Früh", "Spät", "Nacht"}
STATUS = {"DEFECT":"ROT – Defekt", "TECH_INFORMED":"GELB – Technik informiert", "TECH_RELEASED":"PINK – Technik überprüft / Reparatur freigegeben", "CLEANING":"BLAU – Wird gereinigt", "START_READY":"GRÜN – Startklar", "IN_PRODUCTION":"WEISS – In Produktion"}
NOTE_CATEGORIES = ["Ware fehlt", "Verpackungsmaterial fehlt", "Etiketten fehlen", "Buchungen im Firmensystem nicht möglich", "Aufträge nicht abgeschlossen", "Vorreinigung", "Sonderreinigung", "Qualitätsprobleme", "Besondere Maschineneinstellungen", "Produktionsablauf geändert", "Material fehlt", "Technisches Problem ohne vollständigen Anlagenstillstand", "Sonstiges"]
MATERIAL_CATEGORIES = ["Verpackung", "Etiketten", "Produktionsmaterial", "Sonstiges"]
MATERIAL_STATES = ["NEW", "CHECKED", "ORDERED", "DELIVERED", "DONE"]
PRIORITIES = {"NIEDRIG", "NORMAL", "HOCH"}
FORECAST_LABELS = ["Im Laufe der aktuellen Schicht", "Bis zum Ende des heutigen Tages", "Voraussichtlich nächster Tag", "Mehrere Tage", "Längerfristige Reparatur", "Noch keine Einschätzung möglich"]
INITIAL_ASSETS = ["FST 1", "FST 2", "Granulierung 1", "Granulierung 2", "Granulierung 3", "Mühle 1", "Mühle 2", "Mühle 3", "Mühle 4", "Mischer 1", "Mischer 2", "Mischer 3", "Bandtrockner"]
ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
USER_RE = re.compile(r"^[A-Za-z0-9._-]{3,32}$")

SCHEMA = r"""
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, display_name TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('ADMINISTRATOR','SHIFT_LEADER','TECHNICIAN','PRODUCTION')),
 password_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)), must_change INTEGER NOT NULL DEFAULT 0 CHECK(must_change IN (0,1)),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS assets (
 id TEXT PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE, active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
 status TEXT NULL CHECK(status IS NULL OR status IN ('DEFECT','TECH_INFORMED','TECH_RELEASED','CLEANING','START_READY','IN_PRODUCTION')),
 version INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS faults (
 id TEXT PRIMARY KEY, asset_id TEXT NOT NULL REFERENCES assets(id), category TEXT NOT NULL, description TEXT NOT NULL,
 priority TEXT NOT NULL CHECK(priority IN ('NIEDRIG','NORMAL','HOCH')), shift TEXT NOT NULL CHECK(shift IN ('Früh','Spät','Nacht')),
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('OPEN','ACCEPTED','TECH_RELEASED','CLOSED')),
 assignee_id TEXT NULL REFERENCES users(id), diagnosis TEXT NOT NULL DEFAULT '', cause TEXT NOT NULL DEFAULT '',
 measures TEXT NOT NULL DEFAULT '', parts TEXT NOT NULL DEFAULT '', tech_feedback TEXT NOT NULL DEFAULT '', repair_note TEXT NOT NULL DEFAULT '', technical_test TEXT NOT NULL DEFAULT '',
 operational_note TEXT NOT NULL DEFAULT '', tech_released_by TEXT NULL REFERENCES users(id), tech_released_at TEXT NULL,
 closed_by TEXT NULL REFERENCES users(id), closed_at TEXT NULL, version INTEGER NOT NULL DEFAULT 1,
 photo_mime TEXT NULL, photo_data BLOB NULL
);
CREATE TABLE IF NOT EXISTS forecasts (
 id TEXT PRIMARY KEY, fault_id TEXT NOT NULL REFERENCES faults(id), label TEXT NOT NULL, eta_date TEXT NULL,
 eta_time TEXT NULL, note TEXT NOT NULL DEFAULT '', created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS shift_notes (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, category TEXT NOT NULL, description TEXT NOT NULL,
 asset_id TEXT NULL REFERENCES assets(id), area TEXT NOT NULL DEFAULT '', priority TEXT NOT NULL CHECK(priority IN ('NIEDRIG','NORMAL','HOCH')),
 shift TEXT NOT NULL CHECK(shift IN ('Früh','Spät','Nacht')), created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('OPEN','ASSUMED','DONE')), assumed_by TEXT NULL REFERENCES users(id), assumed_at TEXT NULL,
 completed_by TEXT NULL REFERENCES users(id), completed_at TEXT NULL, version INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS materials (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, quantity TEXT NOT NULL DEFAULT '', unit TEXT NOT NULL DEFAULT '',
 asset_id TEXT NULL REFERENCES assets(id), area TEXT NOT NULL DEFAULT '', description TEXT NOT NULL,
 shift TEXT NOT NULL CHECK(shift IN ('Früh','Spät','Nacht')), created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('NEW','CHECKED','ORDERED','DELIVERED','DONE')), version INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS audit_events (
 seq INTEGER PRIMARY KEY AUTOINCREMENT, op_id TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
 action TEXT NOT NULL, actor_id TEXT NULL REFERENCES users(id), shift TEXT NULL, data_json TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_events(entity_type, entity_id, seq);
CREATE TABLE IF NOT EXISTS sync_results (
 op_id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), result_json TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY, csrf_token TEXT NOT NULL, user_id TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL, expires_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
CREATE TABLE IF NOT EXISTS notifications (
 id TEXT PRIMARY KEY, target_role TEXT NULL, target_user TEXT NULL REFERENCES users(id), title TEXT NOT NULL,
 body TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, created_at TEXT NOT NULL, read_at TEXT NULL
);
CREATE INDEX IF NOT EXISTS idx_notifications_target ON notifications(target_role, target_user, created_at);
CREATE TABLE IF NOT EXISTS login_failures (
 key_hash TEXT PRIMARY KEY, attempts INTEGER NOT NULL, window_start TEXT NOT NULL, locked_until TEXT NULL
);
CREATE TABLE IF NOT EXISTS help_links (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', url TEXT NOT NULL,
 active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)), created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1
);
PRAGMA user_version = 4;
"""

class WorksError(Exception):
    def __init__(self, message: str, status: str = "rejected", current=None):
        super().__init__(message); self.status=status; self.current=current
class ConflictError(WorksError):
    def __init__(self, message: str, current=None): super().__init__(message, "conflict", current)
class ForbiddenError(WorksError):
    def __init__(self, message="Keine Berechtigung."): super().__init__(message, "denied")


def now_iso(): return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
def new_id(): return str(uuid.uuid4())
def clean_text(v, label, min_len=0, max_len=2000):
    s = str(v if v is not None else "").strip()
    if len(s) < min_len or len(s) > max_len: raise WorksError(f"{label}: {min_len} bis {max_len} Zeichen erforderlich.")
    if any(ord(ch) < 32 and ch not in "\n\r\t" for ch in s): raise WorksError(f"{label}: unzulässige Steuerzeichen.")
    return s
def valid_id(v):
    s=str(v or "")
    if not ID_RE.fullmatch(s): raise WorksError("Datensatz-ID ungültig.")
    return s

def valid_https_url(value):
    raw=str(value if value is not None else "")
    if raw != raw.strip(): raise WorksError("URL darf keine umschließenden Leerzeichen enthalten.")
    s=clean_text(raw,"URL",1,2048)
    if any(ch.isspace() or ord(ch)<33 or ord(ch)==127 for ch in s) or "\\" in s:
        raise WorksError("URL enthält unzulässige Leer- oder Steuerzeichen.")
    if re.search(r"%(?:0[0-9a-f]|1[0-9a-f]|7f)",s,re.I):
        raise WorksError("URL enthält unzulässige codierte Steuerzeichen.")
    try:
        parts=urlsplit(s)
        hostname=parts.hostname
        _=parts.port
    except ValueError as e:
        raise WorksError("HTTPS-URL ist ungültig.") from e
    if parts.scheme.lower()!="https" or not parts.netloc or not hostname or parts.username is not None or parts.password is not None or "%" in parts.netloc:
        raise WorksError("Nur HTTPS-URLs ohne Zugangsdaten sind erlaubt.")
    return s
def valid_shift(v):
    if v not in SHIFTS: raise WorksError("Schicht muss Früh, Spät oder Nacht sein.")
    return v
def to_json(v): return json.dumps(v, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
def hash_password(password: str) -> str:
    if len(password) < 12 or len(password) > 256: raise WorksError("Passwort muss 12 bis 256 Zeichen haben.")
    salt=secrets.token_bytes(16); digest=hashlib.scrypt(password.encode("utf-8"),salt=salt,n=32768,r=8,p=1,dklen=32,maxmem=64*1024*1024)
    return "scrypt$32768$8$1$"+salt.hex()+"$"+digest.hex()
def verify_password(password: str, stored: str) -> bool:
    try:
        tag,n,r,p,salt_hex,digest_hex=stored.split("$");
        if tag!="scrypt" or (int(n),int(r),int(p))!=(32768,8,1): return False
        salt=bytes.fromhex(salt_hex); expected=bytes.fromhex(digest_hex)
        actual=hashlib.scrypt(str(password).encode("utf-8"),salt=salt,n=32768,r=8,p=1,dklen=len(expected),maxmem=64*1024*1024)
        return hmac.compare_digest(actual,expected)
    except Exception: return False

class ClosingSQLiteConnection(sqlite3.Connection):
    """sqlite connection that is deterministically closed after a with-block."""
    def __exit__(self, exc_type, exc, tb):
        try:
            return super().__exit__(exc_type, exc, tb)
        finally:
            self.close()

class WorksStore:
    def __init__(self, db_path: Path, backup_dir: Path):
        self.db_path=Path(db_path).resolve(); self.backup_dir=Path(backup_dir).resolve(); self.lock=threading.RLock()
        self.db_path.parent.mkdir(parents=True,exist_ok=True); self.backup_dir.mkdir(parents=True,exist_ok=True)
        with self.connect() as c:
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript(SCHEMA)
            user_columns={row[1] for row in c.execute("PRAGMA table_info(users)")}
            if "must_change" not in user_columns:
                c.execute("ALTER TABLE users ADD COLUMN must_change INTEGER NOT NULL DEFAULT 0 CHECK(must_change IN (0,1))")
            fault_columns={row[1] for row in c.execute("PRAGMA table_info(faults)")}
            if "tech_feedback" not in fault_columns:
                c.execute("ALTER TABLE faults ADD COLUMN tech_feedback TEXT NOT NULL DEFAULT ''")
            c.execute("PRAGMA user_version = 4")
            existing=c.execute("SELECT COUNT(*) FROM assets").fetchone()[0]
            if existing==0:
                for index,name in enumerate(INITIAL_ASSETS,1):
                    slug=re.sub(r"[^a-z0-9]+","-",name.lower()).strip("-")
                    c.execute("INSERT INTO assets(id,name,status,version,created_at,updated_at) VALUES(?,?,NULL,1,?,?)",(slug,name,now_iso(),now_iso()))
            c.commit()
        os.chmod(self.db_path,0o600)
        os.chmod(self.backup_dir,0o700)
        for side in (Path(str(self.db_path)+"-wal"),Path(str(self.db_path)+"-shm")):
            if side.exists():os.chmod(side,0o600)
    def connect(self):
        c=sqlite3.connect(self.db_path,timeout=10,isolation_level=None,factory=ClosingSQLiteConnection)
        c.row_factory=sqlite3.Row; c.execute("PRAGMA foreign_keys=ON"); c.execute("PRAGMA busy_timeout=10000")
        return c
    @staticmethod
    def _dict(row): return dict(row) if row is not None else None
    def bootstrap_admin(self, username, display_name, password):
        username=clean_text(username,"Benutzername",3,32)
        if not USER_RE.fullmatch(username): raise WorksError("Benutzername: 3–32 Zeichen, Buchstaben, Zahlen, Punkt, Bindestrich oder Unterstrich.")
        with self.lock, self.connect() as c:
            if c.execute("SELECT 1 FROM users WHERE role='ADMINISTRATOR' AND active=1 LIMIT 1").fetchone(): raise WorksError("Ein aktiver Administrator ist bereits vorhanden.")
            uid=new_id(); ts=now_iso(); ph=hash_password(password)
            c.execute("INSERT INTO users(id,username,display_name,role,password_hash,active,created_at,updated_at) VALUES(?,?,?,'ADMINISTRATOR',?,1,?,?)",(uid,username,clean_text(display_name,"Anzeigename",1,80),ph,ts,ts))
            c.execute("INSERT INTO audit_events(op_id,entity_type,entity_id,action,actor_id,data_json,created_at) VALUES(?,?,?,?,?,?,?)",("bootstrap-"+new_id(),"user",uid,"ADMIN_BOOTSTRAP",uid,to_json({"username":username}),ts))
    def _user(self,c,user_id): return self._dict(c.execute("SELECT id,username,display_name,role,active,must_change,created_at,version FROM users WHERE id=?",(user_id,)).fetchone())
    def authenticate(self, username, password, remote_key):
        username=str(username or "").strip()[:32]
        if not USER_RE.fullmatch(username): raise WorksError("Benutzername oder Passwort falsch.","unauthorized")
        key=hashlib.sha256((username.casefold()+"|"+remote_key).encode()).hexdigest(); ts=datetime.now(timezone.utc)
        with self.lock,self.connect() as c:
            row=c.execute("SELECT attempts,window_start,locked_until FROM login_failures WHERE key_hash=?",(key,)).fetchone()
            if row and row["locked_until"] and row["locked_until"]>now_iso(): raise WorksError("Zu viele Fehlversuche. Anmeldung vorübergehend gesperrt.","locked")
            user=c.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE AND active=1",(username,)).fetchone()
            if not user or not verify_password(str(password or ""),user["password_hash"]):
                start=row["window_start"] if row else now_iso(); attempts=(row["attempts"] if row else 0)+1
                if row and (ts-datetime.fromisoformat(row["window_start"].replace("Z","+00:00"))).total_seconds()>900: start=now_iso();attempts=1
                locked=(ts+timedelta(minutes=5)).replace(microsecond=0).isoformat().replace("+00:00","Z") if attempts>=5 else None
                c.execute("INSERT INTO login_failures(key_hash,attempts,window_start,locked_until) VALUES(?,?,?,?) ON CONFLICT(key_hash) DO UPDATE SET attempts=excluded.attempts,window_start=excluded.window_start,locked_until=excluded.locked_until",(key,attempts,start,locked))
                c.commit();raise WorksError("Benutzername oder Passwort falsch.","unauthorized")
            c.execute("DELETE FROM login_failures WHERE key_hash=?",(key,));c.commit()
            return self._user(c,user["id"])
    def create_session(self,user_id):
        token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(24);ts=datetime.now(timezone.utc);expiry=(ts+timedelta(hours=12)).replace(microsecond=0).isoformat().replace("+00:00","Z")
        with self.lock,self.connect() as c:
            c.execute("DELETE FROM sessions WHERE expires_at<=?",(now_iso(),))
            c.execute("INSERT INTO sessions(token_hash,csrf_token,user_id,created_at,expires_at) VALUES(?,?,?,?,?)",(hashlib.sha256(token.encode()).hexdigest(),csrf,user_id,now_iso(),expiry));c.commit()
        return token,csrf,expiry
    def get_session(self, token):
        if not token:return None
        th=hashlib.sha256(token.encode()).hexdigest()
        with self.lock,self.connect() as c:
            row=c.execute("SELECT s.csrf_token,s.expires_at,u.id,u.username,u.display_name,u.role,u.active,u.must_change FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?",(th,)).fetchone()
            if not row or not row["active"] or row["expires_at"]<=now_iso(): return None
            return {"user":{"id":row["id"],"username":row["username"],"display_name":row["display_name"],"role":row["role"],"must_change":bool(row["must_change"])},"csrf":row["csrf_token"],"expires_at":row["expires_at"]}
    def logout(self,token):
        if token:
            with self.lock,self.connect() as c:c.execute("DELETE FROM sessions WHERE token_hash=?",(hashlib.sha256(token.encode()).hexdigest(),));c.commit()
    def _audit(self,c,op_id,etype,eid,action,user,shift,data):
        c.execute("INSERT INTO audit_events(op_id,entity_type,entity_id,action,actor_id,shift,data_json,created_at) VALUES(?,?,?,?,?,?,?,?)",(op_id,etype,eid,action,user["id"],shift,to_json(data),now_iso()))
        return c.execute("SELECT last_insert_rowid()").fetchone()[0]
    def _notify(self,c,role,title,body,etype,eid,user_id=None):
        c.execute("INSERT INTO notifications(id,target_role,target_user,title,body,entity_type,entity_id,created_at) VALUES(?,?,?,?,?,?,?,?)",(new_id(),role,user_id,title,body,etype,eid,now_iso()))
    def _asset(self,c,aid):
        row=c.execute("SELECT * FROM assets WHERE id=?",(aid,)).fetchone()
        if not row: raise WorksError("Anlage nicht gefunden.")
        return self._dict(row)
    def _fault(self,c,fid):
        row=c.execute("SELECT * FROM faults WHERE id=?",(fid,)).fetchone()
        if not row: raise WorksError("Technikmeldung nicht gefunden.")
        return self._dict(row)
    def _note(self,c,nid):
        row=c.execute("SELECT * FROM shift_notes WHERE id=?",(nid,)).fetchone()
        if not row: raise WorksError("Schichtbesonderheit nicht gefunden.")
        return self._dict(row)
    def _material(self,c,mid):
        row=c.execute("SELECT * FROM materials WHERE id=?",(mid,)).fetchone()
        if not row: raise WorksError("Materialmeldung nicht gefunden.")
        return self._dict(row)
    def _require(self,user,*roles):
        if user["role"] not in roles: raise ForbiddenError()
    def _base(self,provided,current,label):
        if provided is None: raise WorksError("Versionsnummer fehlt; Daten neu laden.")
        try:provided=int(provided)
        except (TypeError,ValueError):raise WorksError("Versionsnummer ungültig.")
        if provided!=int(current["version"]): raise ConflictError(f"{label} wurde zwischenzeitlich geändert. Neu laden und prüfen.",current)
    def _photo(self,data):
        if not data:return None,None
        if not isinstance(data,str) or "," not in data: raise WorksError("Fotoformat ungültig.")
        head,b64=data.split(",",1); allowed={"data:image/jpeg;base64":"image/jpeg","data:image/png;base64":"image/png","data:image/webp;base64":"image/webp"}
        mime=allowed.get(head.lower())
        if not mime: raise WorksError("Foto muss JPEG, PNG oder WebP sein.")
        try: raw=base64.b64decode(b64,validate=True)
        except Exception: raise WorksError("Fotodaten beschädigt.")
        if len(raw)>1024*1024: raise WorksError("Foto ist größer als 1 MB.")
        if mime=="image/png" and not raw.startswith(b"\x89PNG\r\n\x1a\n"): raise WorksError("PNG-Datei ungültig.")
        if mime=="image/jpeg" and not raw.startswith(b"\xff\xd8\xff"): raise WorksError("JPEG-Datei ungültig.")
        if mime=="image/webp" and not(raw.startswith(b"RIFF") and raw[8:12]==b"WEBP"): raise WorksError("WebP-Datei ungültig.")
        return mime,raw
    def _dispatch(self,c,user,op):
        typ=str(op.get("type") or ""); eid=valid_id(op.get("entity_id") or ""); payload=op.get("payload",{}); oid=op["op_id"]
        if payload is None:payload={}
        if not isinstance(payload,dict): raise WorksError("Vorgangsdaten müssen ein Objekt sein.")
        if user.get("must_change") and typ!="user.password.change":raise ForbiddenError("Startpasswort muss zuerst geändert werden.")
        ts=now_iso(); shift=payload.get("shift")
        if shift is not None: valid_shift(shift)
        if typ=="fault.create":
            self._require(user,"PRODUCTION","SHIFT_LEADER")
            aid=valid_id(payload.get("asset_id"));asset=self._asset(c,aid)
            if not asset["active"]: raise WorksError("Inaktive Anlage kann nicht gemeldet werden.")
            self._base(op.get("asset_version"),asset,"Anlagenstatus")
            if asset["status"] in ("DEFECT","TECH_INFORMED","TECH_RELEASED"):
                active=c.execute("SELECT * FROM faults WHERE asset_id=? AND status!='CLOSED' ORDER BY created_at DESC LIMIT 1",(aid,)).fetchone()
                raise ConflictError("Für diese Anlage gibt es bereits eine offene Technikmeldung. Prüfen Sie diese vor einer weiteren Meldung.",self._dict(active))
            category=clean_text(payload.get("category"),"Fehlerkategorie",1,80);description=clean_text(payload.get("description"),"Beschreibung",5,2000);priority=str(payload.get("priority") or "NORMAL")
            if priority not in PRIORITIES: raise WorksError("Priorität ungültig.")
            sh=valid_shift(payload.get("shift"));mime,photo=self._photo(payload.get("photo_data"));
            c.execute("INSERT INTO faults(id,asset_id,category,description,priority,shift,created_by,created_at,status,version,photo_mime,photo_data) VALUES(?,?,?,?,?,?,?,?,'OPEN',1,?,?)",(eid,aid,category,description,priority,sh,user["id"],ts,mime,photo))
            c.execute("UPDATE assets SET status='DEFECT',version=version+1,updated_at=? WHERE id=?",(ts,aid))
            self._audit(c,oid,"fault",eid,"FAULT_REPORTED",user,sh,{"asset_id":aid,"category":category,"priority":priority,"description":description,"photo":bool(photo)})
            self._audit(c,oid,"asset",aid,"STATUS_CHANGED",user,sh,{"from":asset["status"],"to":"DEFECT","reason":"Technikmeldung"})
            self._notify(c,"TECHNICIAN","Neue Technikmeldung",f"{asset['name']}: {category}","fault",eid)
            self._notify(c,"SHIFT_LEADER","Neue Technikmeldung",f"{asset['name']}: {description[:120]}","fault",eid)
            return {"status":"accepted","entity_id":eid,"version":1,"message":"Technikmeldung serverseitig gespeichert; Anlagenstatus ROT."}
        if typ=="fault.accept":
            self._require(user,"TECHNICIAN"); f=self._fault(c,eid); self._base(op.get("base_version"),f,"Technikmeldung")
            if f["status"]!="OPEN": raise WorksError("Nur offene Meldungen können übernommen werden.")
            a=self._asset(c,f["asset_id"]);self._base(op.get("asset_version"),a,"Anlage")
            c.execute("UPDATE faults SET status='ACCEPTED',assignee_id=?,version=version+1 WHERE id=?",(user["id"],eid));c.execute("UPDATE assets SET status='TECH_INFORMED',version=version+1,updated_at=? WHERE id=?",(ts,f["asset_id"]))
            self._audit(c,oid,"fault",eid,"FAULT_ACCEPTED",user,f["shift"],{"assignee":user["id"]});self._audit(c,oid,"asset",f["asset_id"],"STATUS_CHANGED",user,f["shift"],{"from":a["status"],"to":"TECH_INFORMED"})
            self._notify(c,"SHIFT_LEADER","Technikmeldung übernommen",f"{a['name']}: Technik hat übernommen.","fault",eid);self._notify(c,None,"Technikmeldung übernommen",f"Technik hat Ihre Meldung zu {a['name']} übernommen.","fault",eid,f["created_by"])
            return {"status":"accepted","entity_id":eid,"version":f["version"]+1,"message":"Meldung übernommen; Status GELB."}
        if typ=="fault.diagnose":
            self._require(user,"TECHNICIAN");f=self._fault(c,eid);self._base(op.get("base_version"),f,"Technikmeldung")
            if f["status"]!="ACCEPTED": raise WorksError("Diagnose erst nach Übernahme dokumentieren.")
            diagnosis=clean_text(payload.get("diagnosis"),"Diagnose",1,2000);cause=clean_text(payload.get("cause"),"Ursache",0,1000);measures=clean_text(payload.get("measures"),"Maßnahmen",0,2000);parts=clean_text(payload.get("parts"),"Ersatzteile",0,1000);comment=clean_text(payload.get("comment"),"Rückmeldung",0,1000)
            if not cause or not measures or not parts or not comment:raise WorksError("Ursache, Maßnahmen, Ersatzteile und Rückmeldung müssen dokumentiert werden; bei Nichtzutreffen bitte ausdrücklich so eintragen.")
            c.execute("UPDATE faults SET diagnosis=?,cause=?,measures=?,parts=?,tech_feedback=?,version=version+1 WHERE id=?",(diagnosis,cause,measures,parts,comment,eid))
            self._audit(c,oid,"fault",eid,"TECH_DIAGNOSIS",user,f["shift"],{"diagnosis":diagnosis,"cause":cause,"measures":measures,"parts":parts,"feedback":comment})
            self._notify(c,"SHIFT_LEADER","Technische Rückmeldung",f"Diagnose zu {self._asset(c,f['asset_id'])['name']} aktualisiert.","fault",eid)
            return {"status":"accepted","entity_id":eid,"version":f["version"]+1,"message":"Diagnose dokumentiert."}
        if typ=="fault.forecast":
            self._require(user,"TECHNICIAN");f=self._fault(c,eid);self._base(op.get("base_version"),f,"Technikmeldung")
            if f["status"] not in ("ACCEPTED",): raise WorksError("Prognose ist nur bei einer laufenden Technikbearbeitung möglich.")
            label=clean_text(payload.get("label"),"Prognose",1,80)
            if label not in FORECAST_LABELS: raise WorksError("Prognose-Auswahl ungültig.")
            date=clean_text(payload.get("eta_date"),"Voraussichtliches Datum",10,10);clock=clean_text(payload.get("eta_time"),"Voraussichtliche Uhrzeit",5,5)
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}",date): raise WorksError("Datum muss JJJJ-MM-TT sein.")
            if not re.fullmatch(r"\d{2}:\d{2}",clock): raise WorksError("Uhrzeit muss HH:MM sein.")
            try:datetime.strptime(date,"%Y-%m-%d");datetime.strptime(clock,"%H:%M")
            except ValueError:raise WorksError("Datum oder Uhrzeit ist kein gültiger Kalender-/Uhrzeitwert.")
            note=clean_text(payload.get("note"),"Prognosehinweis",1,1000);fid=new_id()
            c.execute("INSERT INTO forecasts(id,fault_id,label,eta_date,eta_time,note,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)",(fid,eid,label,date or None,clock or None,note,user["id"],ts));c.execute("UPDATE faults SET version=version+1 WHERE id=?",(eid,))
            self._audit(c,oid,"fault",eid,"FORECAST_UPDATED",user,f["shift"],{"forecast_id":fid,"label":label,"eta_date":date,"eta_time":clock,"note":note,"unverbindlich":True})
            self._notify(c,"SHIFT_LEADER","Reparaturprognose geändert",f"Neue unverbindliche Einschätzung zu {self._asset(c,f['asset_id'])['name']}.","fault",eid)
            return {"status":"accepted","entity_id":eid,"version":f["version"]+1,"message":"Prognose gespeichert; frühere Einschätzungen bleiben erhalten."}
        if typ=="fault.release":
            self._require(user,"TECHNICIAN");f=self._fault(c,eid);self._base(op.get("base_version"),f,"Technikmeldung")
            if f["status"]!="ACCEPTED": raise WorksError("Technische Freigabe setzt eine übernommene Meldung voraus.")
            if not all(f.get(k) for k in ("diagnosis","cause","measures","parts","tech_feedback")):raise WorksError("Technische Freigabe gesperrt: Diagnose, Ursache, Maßnahmen, Ersatzteile und Rückmeldung vollständig dokumentieren.")
            a=self._asset(c,f["asset_id"]);self._base(op.get("asset_version"),a,"Anlage")
            repair=clean_text(payload.get("repair_note"),"Reparaturmaßnahme",1,2000);test=clean_text(payload.get("technical_test"),"Technische Prüfung",1,1500)
            c.execute("UPDATE faults SET status='TECH_RELEASED',repair_note=?,technical_test=?,tech_released_by=?,tech_released_at=?,version=version+1 WHERE id=?",(repair,test,user["id"],ts,eid));c.execute("UPDATE assets SET status='TECH_RELEASED',version=version+1,updated_at=? WHERE id=?",(ts,f["asset_id"]))
            self._audit(c,oid,"fault",eid,"TECHNICAL_RELEASE",user,f["shift"],{"repair_note":repair,"technical_test":test,"operational_release":False});self._audit(c,oid,"asset",f["asset_id"],"STATUS_CHANGED",user,f["shift"],{"from":a["status"],"to":"TECH_RELEASED","operational_release":False})
            self._notify(c,"SHIFT_LEADER","Technische Freigabe dokumentiert",f"{a['name']}: betriebliche Startfreigabe steht noch aus.","fault",eid);self._notify(c,None,"Technische Rückmeldung",f"Technik hat {a['name']} geprüft. Schichtleitung entscheidet über Startklar.","fault",eid,f["created_by"])
            return {"status":"accepted","entity_id":eid,"version":f["version"]+1,"message":"Technische Freigabe dokumentiert. Keine betriebliche Startfreigabe erfolgt."}
        if typ=="fault.close":
            self._require(user,"SHIFT_LEADER");f=self._fault(c,eid);self._base(op.get("base_version"),f,"Technikmeldung")
            if f["status"]!="TECH_RELEASED": raise WorksError("Betriebliche Übernahme erst nach dokumentierter technischer Freigabe.")
            a=self._asset(c,f["asset_id"]);self._base(payload.get("asset_version"),a,"Anlage")
            note=clean_text(payload.get("operational_note"),"Betriebliche Bestätigung",1,1000)
            c.execute("UPDATE faults SET status='CLOSED',operational_note=?,closed_by=?,closed_at=?,version=version+1 WHERE id=?",(note,user["id"],ts,eid));c.execute("UPDATE assets SET status='START_READY',version=version+1,updated_at=? WHERE id=?",(ts,f["asset_id"]))
            self._audit(c,oid,"fault",eid,"OPERATIONAL_ACCEPTANCE",user,f["shift"],{"note":note,"after_technical_release":True});self._audit(c,oid,"asset",f["asset_id"],"STATUS_CHANGED",user,f["shift"],{"from":a["status"],"to":"START_READY","reason":"explizite betriebliche Bestätigung"})
            self._notify(c,"TECHNICIAN","Vorgang betrieblich übernommen",f"{a['name']}: Schichtleitung hat Startklar bestätigt.","fault",eid)
            return {"status":"accepted","entity_id":eid,"version":f["version"]+1,"message":"Vorgang geschlossen; Schichtleitung hat GRÜN – Startklar ausdrücklich bestätigt."}
        if typ=="asset.status":
            self._require(user,"SHIFT_LEADER");a=self._asset(c,eid);self._base(op.get("base_version"),a,"Anlage");valid_shift(payload.get("shift"))
            target=str(payload.get("status") or "")
            if target not in ("CLEANING","START_READY","IN_PRODUCTION"): raise WorksError("Statuswechsel ROT/GELB/PINK erfolgen ausschließlich über dokumentierte Technikmeldungen.")
            old=a["status"]
            allowed={None:{"CLEANING","START_READY","IN_PRODUCTION"},"START_READY":{"CLEANING","IN_PRODUCTION"},"IN_PRODUCTION":{"CLEANING","START_READY"},"CLEANING":{"START_READY","IN_PRODUCTION"}}
            if target not in allowed.get(old,set()): raise WorksError("Dieser Statuswechsel ist nicht zulässig. Offene Technikmeldungen benötigen den getrennten Technik-/Schichtleiterablauf.")
            if old is None and payload.get("initial_confirmed") is not True: raise WorksError("Erststatus muss vor Ort ausdrücklich bestätigt werden.")
            c.execute("UPDATE assets SET status=?,version=version+1,updated_at=? WHERE id=?",(target,ts,eid))
            self._audit(c,oid,"asset",eid,"STATUS_INITIALIZED" if old is None else "STATUS_CHANGED",user,shift,{"from":old,"to":target,"explicit_confirmation":True})
            return {"status":"accepted","entity_id":eid,"version":a["version"]+1,"message":"Anlagenstatus dokumentiert."}
        if typ=="note.create":
            self._require(user,"PRODUCTION","SHIFT_LEADER");nid=eid;title=clean_text(payload.get("title"),"Überschrift",1,120);category=clean_text(payload.get("category"),"Kategorie",1,100)
            if category not in NOTE_CATEGORIES: raise WorksError("Kategorie nicht freigegeben.")
            desc=clean_text(payload.get("description"),"Beschreibung",1,2000);priority=str(payload.get("priority") or "NORMAL")
            if priority not in PRIORITIES: raise WorksError("Priorität ungültig.")
            aid=payload.get("asset_id") or None
            if aid: aid=valid_id(aid);self._asset(c,aid)
            area=clean_text(payload.get("area"),"Bereich",0,100);sh=valid_shift(payload.get("shift"))
            c.execute("INSERT INTO shift_notes(id,title,category,description,asset_id,area,priority,shift,created_by,created_at,status,version) VALUES(?,?,?,?,?,?,?,?,?,?,'OPEN',1)",(nid,title,category,desc,aid,area,priority,sh,user["id"],ts))
            self._audit(c,oid,"note",nid,"NOTE_CREATED",user,sh,{"title":title,"category":category,"description":desc,"asset_id":aid,"area":area,"priority":priority})
            self._notify(c,"SHIFT_LEADER","Neue Schichtbesonderheit",title,"note",nid)
            return {"status":"accepted","entity_id":nid,"version":1,"message":"Schichtbesonderheit gespeichert."}
        if typ in ("note.assume","note.complete","note.amend"):
            n=self._note(c,eid)
            if typ=="note.assume":
                self._require(user,"SHIFT_LEADER");self._base(op.get("base_version"),n,"Schichtbesonderheit")
                if n["status"]!="OPEN": raise WorksError("Nur offene Einträge können übernommen werden.")
                c.execute("UPDATE shift_notes SET status='ASSUMED',assumed_by=?,assumed_at=?,version=version+1 WHERE id=?",(user["id"],ts,eid));action="NOTE_ASSUMED";data={"from":"OPEN","to":"ASSUMED"}
            elif typ=="note.complete":
                self._require(user,"SHIFT_LEADER");self._base(op.get("base_version"),n,"Schichtbesonderheit")
                if n["status"]=="DONE": raise WorksError("Eintrag ist bereits erledigt.")
                c.execute("UPDATE shift_notes SET status='DONE',completed_by=?,completed_at=?,version=version+1 WHERE id=?",(user["id"],ts,eid));action="NOTE_COMPLETED";data={"from":n["status"],"to":"DONE"}
            else:
                if user["role"] not in ("SHIFT_LEADER","PRODUCTION") or (user["role"]=="PRODUCTION" and user["id"]!=n["created_by"]): raise ForbiddenError()
                self._base(op.get("base_version"),n,"Schichtbesonderheit");addition=clean_text(payload.get("addition"),"Ergänzung",1,1500)
                c.execute("UPDATE shift_notes SET description=description||char(10)||? ,version=version+1 WHERE id=?",("Ergänzung ("+user["username"]+", "+ts+"): "+addition,eid));action="NOTE_AMENDED";data={"addition":addition}
            self._audit(c,oid,"note",eid,action,user,n["shift"],data);return {"status":"accepted","entity_id":eid,"version":n["version"]+1,"message":"Schichtbesonderheit aktualisiert."}
        if typ=="material.create":
            self._require(user,"PRODUCTION","SHIFT_LEADER");name=clean_text(payload.get("name"),"Bezeichnung",1,120);cat=clean_text(payload.get("category"),"Kategorie",1,80)
            if cat not in MATERIAL_CATEGORIES: raise WorksError("Materialkategorie nicht freigegeben.")
            quantity=clean_text(payload.get("quantity"),"Menge",0,40);unit=clean_text(payload.get("unit"),"Einheit",0,30);aid=payload.get("asset_id") or None
            if aid:aid=valid_id(aid);self._asset(c,aid)
            area=clean_text(payload.get("area"),"Bereich",0,100);desc=clean_text(payload.get("description"),"Beschreibung",0,1000);sh=valid_shift(payload.get("shift"))
            c.execute("INSERT INTO materials(id,name,category,quantity,unit,asset_id,area,description,shift,created_by,created_at,status,version) VALUES(?,?,?,?,?,?,?,?,?,?,?,'NEW',1)",(eid,name,cat,quantity,unit,aid,area,desc,sh,user["id"],ts))
            self._audit(c,oid,"material",eid,"MATERIAL_CREATED",user,sh,{"name":name,"category":cat,"quantity":quantity,"unit":unit,"asset_id":aid,"area":area,"description":desc})
            self._notify(c,"SHIFT_LEADER","Neuer Materialbedarf",name,"material",eid);return {"status":"accepted","entity_id":eid,"version":1,"message":"Materialbedarf gespeichert."}
        if typ=="material.status":
            self._require(user,"SHIFT_LEADER");m=self._material(c,eid);self._base(op.get("base_version"),m,"Materialmeldung");target=str(payload.get("status") or "")
            i=MATERIAL_STATES.index(m["status"])
            if i>=len(MATERIAL_STATES)-1 or target!=MATERIAL_STATES[i+1]: raise WorksError("Status muss in der Reihenfolge NEU → GEPRÜFT → BESTELLT → GELIEFERT → ERLEDIGT wechseln.")
            c.execute("UPDATE materials SET status=?,version=version+1 WHERE id=?",(target,eid));self._audit(c,oid,"material",eid,"MATERIAL_STATUS",user,m["shift"],{"from":m["status"],"to":target});self._notify(c,None,"Materialbedarf aktualisiert",f"{m['name']}: {target}","material",eid,m["created_by"])
            return {"status":"accepted","entity_id":eid,"version":m["version"]+1,"message":"Materialstatus aktualisiert."}
        if typ=="admin.help_link.create":
            self._require(user,"ADMINISTRATOR")
            title=clean_text(payload.get("title"),"Titel",1,100)
            description=clean_text(payload.get("description"),"Beschreibung",0,500)
            url=valid_https_url(payload.get("url"))
            if c.execute("SELECT 1 FROM help_links WHERE id=?",(eid,)).fetchone():raise WorksError("Hilfelink-ID existiert bereits.")
            c.execute("INSERT INTO help_links(id,title,description,url,active,created_by,created_at,updated_at,version) VALUES(?,?,?,?,1,?,?,?,1)",(eid,title,description,url,user["id"],ts,ts))
            self._audit(c,oid,"help_link",eid,"HELP_LINK_CREATED",user,None,{"title":title,"url":url,"active":True})
            return {"status":"accepted","entity_id":eid,"version":1,"message":"Hilfelink gespeichert."}
        if typ=="admin.help_link.active":
            self._require(user,"ADMINISTRATOR")
            link=c.execute("SELECT * FROM help_links WHERE id=?",(eid,)).fetchone()
            if not link:raise WorksError("Hilfelink nicht gefunden.")
            current=self._dict(link);self._base(op.get("base_version"),current,"Hilfelink")
            if not isinstance(payload.get("active"),bool):raise WorksError("Aktivstatus muss true oder false sein.")
            active=payload["active"]
            if active==bool(link["active"]):raise WorksError("Keine Änderung am Linkstatus.")
            c.execute("UPDATE help_links SET active=?,version=version+1,updated_at=? WHERE id=?",(int(active),ts,eid))
            self._audit(c,oid,"help_link",eid,"HELP_LINK_ACTIVATED" if active else "HELP_LINK_DEACTIVATED",user,None,{"title":link["title"],"url":link["url"],"active":active})
            return {"status":"accepted","entity_id":eid,"version":link["version"]+1,"message":"Hilfelink aktualisiert."}
        if typ=="admin.asset.create":
            self._require(user,"ADMINISTRATOR");name=clean_text(payload.get("name"),"Anlagenname",1,100)
            if c.execute("SELECT 1 FROM assets WHERE name=? COLLATE NOCASE",(name,)).fetchone(): raise WorksError("Anlagenname existiert bereits.")
            c.execute("INSERT INTO assets(id,name,active,status,version,created_at,updated_at) VALUES(?,?,1,NULL,1,?,?)",(eid,name,ts,ts));self._audit(c,oid,"asset",eid,"ASSET_CREATED",user,None,{"name":name});return {"status":"accepted","entity_id":eid,"version":1,"message":"Anlage hinzugefügt; Status muss vor Ort bestätigt werden."}
        if typ=="admin.asset.update":
            self._require(user,"ADMINISTRATOR");a=self._asset(c,eid);self._base(op.get("base_version"),a,"Anlage");name=clean_text(payload.get("name"),"Anlagenname",1,100)
            if c.execute("SELECT 1 FROM assets WHERE name=? COLLATE NOCASE AND id<>?",(name,eid)).fetchone():raise WorksError("Anlagenname existiert bereits.")
            c.execute("UPDATE assets SET name=?,version=version+1,updated_at=? WHERE id=?",(name,ts,eid));self._audit(c,oid,"asset",eid,"ASSET_RENAMED",user,None,{"from":a["name"],"to":name});return {"status":"accepted","entity_id":eid,"version":a["version"]+1,"message":"Anlage umbenannt."}
        if typ=="admin.asset.active":
            self._require(user,"ADMINISTRATOR");a=self._asset(c,eid);self._base(op.get("base_version"),a,"Anlage")
            if not isinstance(payload.get("active"),bool):raise WorksError("Aktivstatus muss true oder false sein.")
            active=payload["active"]
            if active==bool(a["active"]):raise WorksError("Keine Änderung am Anlagenstatus.")
            c.execute("UPDATE assets SET active=?,version=version+1,updated_at=? WHERE id=?",(int(active),ts,eid));self._audit(c,oid,"asset",eid,"ASSET_ACTIVATED" if active else "ASSET_DEACTIVATED",user,None,{"name":a["name"],"active":active});return {"status":"accepted","entity_id":eid,"version":a["version"]+1,"message":"Anlagenstamm aktualisiert."}
        if typ=="admin.user.create":
            self._require(user,"ADMINISTRATOR");username=clean_text(payload.get("username"),"Benutzername",3,32)
            if not USER_RE.fullmatch(username):raise WorksError("Benutzername: 3–32 Zeichen, Buchstaben, Zahlen, Punkt, Bindestrich oder Unterstrich.")
            role=str(payload.get("role") or "");
            if role not in ROLES:raise WorksError("Rolle ungültig.")
            display=clean_text(payload.get("display_name"),"Anzeigename",1,80);password=str(payload.get("password") or "");ph=hash_password(password)
            if c.execute("SELECT 1 FROM users WHERE username=? COLLATE NOCASE",(username,)).fetchone():raise WorksError("Benutzername existiert bereits.")
            c.execute("INSERT INTO users(id,username,display_name,role,password_hash,active,must_change,created_at,updated_at) VALUES(?,?,?,?,?,1,1,?,?)",(eid,username,display,role,ph,ts,ts));self._audit(c,oid,"user",eid,"USER_CREATED",user,None,{"username":username,"role":role,"display_name":display});return {"status":"accepted","entity_id":eid,"version":1,"message":"Benutzerkonto erstellt."}
        if typ=="admin.user.update":
            self._require(user,"ADMINISTRATOR");target=c.execute("SELECT * FROM users WHERE id=?",(eid,)).fetchone()
            if not target:raise WorksError("Benutzerkonto nicht gefunden.")
            self._base(op.get("base_version"),self._dict(target),"Benutzerkonto")
            changes={};
            if "display_name" in payload:changes["display_name"]=clean_text(payload["display_name"],"Anzeigename",1,80)
            if "role" in payload:
                role=str(payload["role"])
                if role not in ROLES:raise WorksError("Rolle ungültig.")
                if eid==user["id"] and role!="ADMINISTRATOR":raise WorksError("Eigene Administratorrolle kann nicht geändert werden.")
                if role!=target["role"]:
                    if target["role"]=="ADMINISTRATOR" and target["active"] and role!="ADMINISTRATOR" and c.execute("SELECT COUNT(*) FROM users WHERE role='ADMINISTRATOR' AND active=1").fetchone()[0]<=1:raise WorksError("Mindestens ein aktives Administrationskonto muss bestehen bleiben.")
                    changes["role"]=role
            if "active" in payload:
                if not isinstance(payload["active"],bool):raise WorksError("Aktivstatus muss true oder false sein.")
                active=int(payload["active"])
                if eid==user["id"] and not active:raise WorksError("Eigenes Konto kann nicht deaktiviert werden.")
                if not active and target["role"]=="ADMINISTRATOR" and c.execute("SELECT COUNT(*) FROM users WHERE role='ADMINISTRATOR' AND active=1").fetchone()[0]<=1:raise WorksError("Mindestens ein aktives Administrationskonto muss bestehen bleiben.")
                if active!=int(target["active"]):changes["active"]=active
            if "password" in payload:
                if eid==user["id"]:raise WorksError("Eigenes Passwort über Mein Konto ändern.")
                changes["password_hash"]=hash_password(str(payload["password"]));changes["must_change"]=1
            if not changes:raise WorksError("Keine gültigen Änderungen.")
            changes["updated_at"]=ts;changes["version"]=int(target["version"])+1;sql="UPDATE users SET "+",".join(k+"=?" for k in changes)+" WHERE id=?";c.execute(sql,(*changes.values(),eid));
            if "password_hash" in changes or "role" in changes or "active" in changes:c.execute("DELETE FROM sessions WHERE user_id=?",(eid,))
            self._audit(c,oid,"user",eid,"USER_UPDATED",user,None,{k:("[gesetzt]" if k=="password_hash" else v) for k,v in changes.items() if k not in ("updated_at","version")});return {"status":"accepted","entity_id":eid,"version":int(target["version"])+1,"message":"Benutzerkonto aktualisiert."}
        if typ=="user.password.change":
            target=c.execute("SELECT * FROM users WHERE id=?",(user["id"],)).fetchone();old=str(payload.get("current_password") or "")
            if not verify_password(old,target["password_hash"]):raise ForbiddenError("Aktuelles Passwort ist falsch.")
            new=str(payload.get("new_password") or "");ph=hash_password(new);c.execute("UPDATE users SET password_hash=?,must_change=0,updated_at=?,version=version+1 WHERE id=?",(ph,ts,user["id"]));
            keep=user.get("_session_hash");
            if keep:c.execute("DELETE FROM sessions WHERE user_id=? AND token_hash<>?",(user["id"],keep))
            else:c.execute("DELETE FROM sessions WHERE user_id=?",(user["id"],))
            new_version=c.execute("SELECT version FROM users WHERE id=?",(user["id"],)).fetchone()[0]
            self._audit(c,oid,"user",user["id"],"PASSWORD_CHANGED",user,None,{"password":"[nicht protokolliert]"});return {"status":"accepted","entity_id":user["id"],"version":new_version,"message":"Passwort geändert."}
        raise WorksError("Unbekannter Vorgangstyp.")
    def apply_operation(self,user,op):
        if not isinstance(op,dict):return {"op_id":"?","status":"rejected","message":"Vorgang ungültig."}
        oid=str(op.get("op_id") or "")
        if not ID_RE.fullmatch(oid):return {"op_id":oid or "?","status":"rejected","message":"Vorgangs-ID ungültig."}
        with self.lock,self.connect() as c:
            c.execute("BEGIN IMMEDIATE")
            try:
                prior=c.execute("SELECT result_json,user_id FROM sync_results WHERE op_id=?",(oid,)).fetchone()
                if prior:
                    if prior["user_id"]==user["id"]:c.commit();return json.loads(prior["result_json"])
                    c.commit();return {"status":"rejected","op_id":oid,"message":"Vorgangs-ID wurde bereits von einem anderen Konto verwendet."}
                try: result=self._dispatch(c,user,op)
                except WorksError as e: result={"status":e.status,"op_id":oid,"message":str(e),"current":e.current}
                result["op_id"]=oid
                c.execute("INSERT INTO sync_results(op_id,user_id,result_json,created_at) VALUES(?,?,?,?)",(oid,user["id"],to_json(result),now_iso()));c.commit();return result
            except Exception:
                c.rollback();raise
    def _visible(self,role,table,row,user_id):
        if role in ("ADMINISTRATOR","SHIFT_LEADER"):return True
        if role=="TECHNICIAN":return table=="faults" or table=="assets" or table=="audit"
        if role=="PRODUCTION":return table=="assets" or row.get("created_by")==user_id or (table=="audit" and row.get("actor_id")==user_id)
        return False
    def snapshot(self,user):
        with self.lock,self.connect() as c:
            assets=[dict(r) for r in c.execute("SELECT id,name,active,status,version,created_at,updated_at FROM assets ORDER BY name COLLATE NOCASE")]
            all_faults=[dict(r) for r in c.execute("SELECT f.id,f.asset_id,a.name AS asset_name,f.category,f.description,f.priority,f.shift,f.created_by,u.display_name AS reporter,f.created_at,f.status,f.assignee_id,au.display_name AS assignee,f.diagnosis,f.cause,f.measures,f.parts,f.tech_feedback AS feedback,f.repair_note,f.technical_test,f.operational_note,f.tech_released_by,f.tech_released_at,f.closed_by,f.closed_at,f.version,CASE WHEN f.photo_data IS NULL THEN 0 ELSE 1 END AS has_photo FROM faults f JOIN assets a ON a.id=f.asset_id JOIN users u ON u.id=f.created_by LEFT JOIN users au ON au.id=f.assignee_id ORDER BY f.created_at DESC")]
            faults=[f for f in all_faults if self._visible(user["role"],"faults",f,user["id"])]
            forecasts={}
            if faults:
                marks=','.join('?' for _ in faults)
                for row in c.execute(f"SELECT p.*,u.display_name AS author FROM forecasts p JOIN users u ON u.id=p.created_by WHERE p.fault_id IN ({marks}) ORDER BY p.created_at DESC, p.rowid DESC",[f["id"] for f in faults]):forecasts.setdefault(row["fault_id"],[]).append(dict(row))
            notes=[];materials=[]
            if user["role"] in ("ADMINISTRATOR","SHIFT_LEADER","PRODUCTION"):
                raw=[dict(r) for r in c.execute("SELECT n.*,a.name AS asset_name,u.display_name AS reporter,au.display_name AS assumed_by_name,cu.display_name AS completed_by_name FROM shift_notes n LEFT JOIN assets a ON a.id=n.asset_id JOIN users u ON u.id=n.created_by LEFT JOIN users au ON au.id=n.assumed_by LEFT JOIN users cu ON cu.id=n.completed_by ORDER BY n.created_at DESC")]
                notes=[n for n in raw if self._visible(user["role"],"shift_notes",n,user["id"])]
                rawm=[dict(r) for r in c.execute("SELECT m.*,a.name AS asset_name,u.display_name AS reporter FROM materials m LEFT JOIN assets a ON a.id=m.asset_id JOIN users u ON u.id=m.created_by ORDER BY m.created_at DESC")]
                materials=[m for m in rawm if self._visible(user["role"],"materials",m,user["id"])]
            users=[]
            if user["role"]=="ADMINISTRATOR":users=[dict(r) for r in c.execute("SELECT id,username,display_name,role,active,must_change,created_at,version FROM users ORDER BY username COLLATE NOCASE")]
            help_links=[dict(r) for r in c.execute("SELECT id,title,description,url,active,created_at,updated_at,version FROM help_links WHERE active=1 OR ?='ADMINISTRATOR' ORDER BY title COLLATE NOCASE",(user["role"],))]
            ids={f['id'] for f in faults}|{n['id'] for n in notes}|{m['id'] for m in materials}|{a['id'] for a in assets}
            history=[]
            if ids:
                for r in c.execute("SELECT seq,op_id,entity_type,entity_id,action,actor_id,shift,data_json,created_at FROM audit_events ORDER BY seq DESC LIMIT 5000"):
                    if r["entity_id"] in ids:
                        item=dict(r);item["data"]=json.loads(item.pop("data_json"));actor=c.execute("SELECT display_name FROM users WHERE id=?",(item["actor_id"],)).fetchone();item["actor"]=actor[0] if actor else "System";history.append(item)
            max_seq=c.execute("SELECT COALESCE(MAX(seq),0) FROM audit_events").fetchone()[0]
            for f in faults:f["forecasts"]=forecasts.get(f["id"],[])
            return {"app_version":APP_VERSION,"schema_version":SCHEMA_VERSION,"assets":assets,"faults":faults,"notes":notes,"materials":materials,"users":users,"help_links":help_links,"history":history,"last_seq":max_seq,"server_time":now_iso(),"role":user["role"]}
    def notifications(self,user,after=""):
        with self.lock,self.connect() as c:
            rows=c.execute("SELECT * FROM notifications WHERE created_at>? AND ((target_role=? AND target_user IS NULL) OR target_user=?) ORDER BY created_at DESC LIMIT 100",(after,user["role"],user["id"])).fetchall()
            return [dict(r) for r in rows]
    def mark_notification(self,user,nid):
        with self.lock,self.connect() as c:
            c.execute("UPDATE notifications SET read_at=? WHERE id=? AND ((target_role=? AND target_user IS NULL) OR target_user=?)",(now_iso(),nid,user["role"],user["id"]));c.commit()
    def archive(self,user,filters):
        snap=self.snapshot(user);data=[]
        for collection,etype in ((snap['faults'],'fault'),(snap['notes'],'note'),(snap['materials'],'material')):
            for row in collection:
                row=dict(row);row['entity_type']=etype;data.append(row)
        date_from=filters.get('from','');date_to=filters.get('to','');shift=filters.get('shift','');asset=filters.get('asset','');category=filters.get('category','');status=filters.get('status','');creator=filters.get('creator','')
        def matches(row):
            if date_from and row.get('created_at','')[:10]<date_from:return False
            if date_to and row.get('created_at','')[:10]>date_to:return False
            if shift and row.get('shift')!=shift:return False
            if asset and row.get('asset_id')!=asset:return False
            if category and category.lower() not in str(row.get('category','')).lower():return False
            if status and row.get('status')!=status:return False
            if creator and creator.lower() not in str(row.get('reporter','')).lower():return False
            return True
        return sorted((x for x in data if matches(x)),key=lambda x:x.get('created_at',''),reverse=True)[:1000]
    def backup_archive(self):
        with self.lock:
            self.backup_dir.mkdir(parents=True,exist_ok=True)
            fd,tmp=tempfile.mkstemp(prefix="works-backup-",suffix=".sqlite3",dir=str(self.backup_dir));os.close(fd)
            try:
                with self.connect() as src,sqlite3.connect(tmp,factory=ClosingSQLiteConnection) as dst:src.backup(dst)
                os.chmod(tmp,0o600)
                with sqlite3.connect(tmp,factory=ClosingSQLiteConnection) as check:
                    result=check.execute("PRAGMA integrity_check").fetchone()[0]
                    if result!="ok":raise WorksError("Backup-Integritätsprüfung fehlgeschlagen.")
                    schema=check.execute("PRAGMA user_version").fetchone()[0]
                data=Path(tmp).read_bytes();manifest={"app":"SHIFT SUPERVISOR DELUXE WORKS EDITION","version":APP_VERSION,"schema":schema,"created_at":now_iso(),"size":len(data),"sha256":hashlib.sha256(data).hexdigest(),"integrity_check":"ok"}
                out=io.BytesIO()
                with zipfile.ZipFile(out,"w",compression=zipfile.ZIP_DEFLATED) as z:z.writestr("works.sqlite3",data);z.writestr("manifest.json",to_json(manifest))
                package=out.getvalue();name="works-backup-"+datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")+".zip";dest=self.backup_dir/name;dest.write_bytes(package);os.chmod(dest,0o600)
                return name,package,manifest
            finally:
                try:os.unlink(tmp)
                except OSError:pass
    def _validate_backup(self,archive_bytes):
        if len(archive_bytes)>100*1024*1024:raise WorksError("Backupdatei größer als 100 MB.")
        tmp=None
        try:
            with zipfile.ZipFile(io.BytesIO(archive_bytes)) as z:
                names=set(z.namelist())
                if names!={"works.sqlite3","manifest.json"}:raise WorksError("Backup-Archiv enthält unerwartete Dateien.")
                if z.testzip() is not None:raise WorksError("Backup-Archiv beschädigt.")
                dbinfo=z.getinfo("works.sqlite3");mi=z.getinfo("manifest.json")
                if dbinfo.file_size>100*1024*1024 or mi.file_size>16384:raise WorksError("Backup-Inhalt überschreitet die Grenze.")
                dbbytes=z.read("works.sqlite3");manifest=json.loads(z.read("manifest.json"))
            backup_schema=manifest.get("schema")
            if manifest.get("app")!="SHIFT SUPERVISOR DELUXE WORKS EDITION" or backup_schema not in (3,SCHEMA_VERSION):raise WorksError("Backup stammt nicht aus einem unterstützten Works-Schema.")
            if manifest.get("size")!=len(dbbytes) or not hmac.compare_digest(str(manifest.get("sha256","")),hashlib.sha256(dbbytes).hexdigest()):raise WorksError("Backup-Prüfsumme stimmt nicht.")
            fd,tmp=tempfile.mkstemp(prefix="works-restore-check-",suffix=".sqlite3",dir=str(self.backup_dir));os.close(fd);Path(tmp).write_bytes(dbbytes)
            migrate=sqlite3.connect(tmp,factory=ClosingSQLiteConnection)
            try:
                original_schema=migrate.execute("PRAGMA user_version").fetchone()[0]
                if original_schema!=backup_schema:raise WorksError("Backup-Manifest und Datenbankschema stimmen nicht überein.")
                if original_schema==3:
                    migrate.executescript(SCHEMA)
                    migrate.commit()
            finally:migrate.close()
            c=sqlite3.connect(f"file:{tmp}?mode=ro",uri=True,factory=ClosingSQLiteConnection);c.row_factory=sqlite3.Row
            if c.execute("PRAGMA integrity_check").fetchone()[0]!="ok":raise WorksError("SQLite-Integritätsprüfung fehlgeschlagen.")
            if c.execute("PRAGMA user_version").fetchone()[0]!=SCHEMA_VERSION:raise WorksError("Datenbankschema wird nicht unterstützt.")
            tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            required={"users","assets","faults","forecasts","shift_notes","materials","audit_events","sessions","notifications","sync_results","login_failures","help_links"}
            if not required.issubset(tables):raise WorksError("Backup enthält nicht alle Works-Tabellen.")
            required_columns={"users":{"id","username","display_name","role","password_hash","active","must_change","created_at","updated_at","version"},"assets":{"id","name","active","status","version","created_at","updated_at"},"faults":{"id","asset_id","category","description","priority","shift","created_by","created_at","status","diagnosis","cause","measures","parts","tech_feedback","repair_note","technical_test","version","photo_mime","photo_data"},"forecasts":{"id","fault_id","label","eta_date","eta_time","note","created_by","created_at"},"shift_notes":{"id","title","category","description","shift","created_by","status","version"},"materials":{"id","name","category","quantity","unit","description","shift","created_by","status","version"},"audit_events":{"seq","op_id","entity_type","entity_id","action","actor_id","shift","data_json","created_at"},"sessions":{"token_hash","csrf_token","user_id","created_at","expires_at"},"notifications":{"id","target_role","target_user","title","body","entity_type","entity_id","created_at","read_at"},"sync_results":{"op_id","user_id","result_json","created_at"},"login_failures":{"key_hash","attempts","window_start","locked_until"},"help_links":{"id","title","description","url","active","created_by","created_at","updated_at","version"}}
            for table,columns in required_columns.items():
                actual={row[1] for row in c.execute(f"PRAGMA table_info({table})")}
                if not columns.issubset(actual):raise WorksError(f"Backup-Tabelle {table} ist unvollständig.")
            if c.execute("PRAGMA foreign_key_check").fetchone():raise WorksError("Backup enthält ungültige Fremdschlüssel.")
            if c.execute("SELECT COUNT(*) FROM users WHERE active=1 AND role='ADMINISTRATOR'").fetchone()[0]<1:raise WorksError("Backup enthält keinen aktiven Administrator.")
            if c.execute("SELECT COUNT(*) FROM assets WHERE status IS NOT NULL AND status NOT IN ('DEFECT','TECH_INFORMED','TECH_RELEASED','CLEANING','START_READY','IN_PRODUCTION')").fetchone()[0]:raise WorksError("Backup enthält ungültige Anlagenstatus.")
            c.close();dbbytes=Path(tmp).read_bytes();return dbbytes,manifest
        except WorksError:raise
        except Exception as e:raise WorksError("Backup ist beschädigt oder ungültig.") from e
        finally:
            if tmp:
                try:os.unlink(tmp)
                except OSError:pass
    def restore_archive(self,archive_bytes,actor):
        with self.lock:
            dbbytes,manifest=self._validate_backup(archive_bytes)
            backup_name,_,_=self.backup_archive()
            fd,tmp=tempfile.mkstemp(prefix="works-restore-",suffix=".sqlite3",dir=str(self.db_path.parent));os.close(fd);Path(tmp).write_bytes(dbbytes);os.chmod(tmp,0o600)
            try:
                for suffix in ("-wal","-shm"):
                    side=Path(str(self.db_path)+suffix)
                    if side.exists():side.unlink()
                os.replace(tmp,self.db_path)
                with self.connect() as c:
                    c.execute("DELETE FROM sessions")
                    actor_row=c.execute("SELECT id FROM users WHERE id=? AND active=1",(actor["id"],)).fetchone()
                    c.execute("INSERT INTO audit_events(op_id,entity_type,entity_id,action,actor_id,data_json,created_at) VALUES(?,?,?,?,?,?,?)",("restore-"+new_id(),"system","database","DATABASE_RESTORED",actor_row[0] if actor_row else None,to_json({"backup_created_at":manifest.get("created_at"),"safety_backup":backup_name}),now_iso()))
                    c.commit();c.execute("PRAGMA journal_mode=WAL")
                return {"safety_backup":backup_name,"restored_schema":SCHEMA_VERSION,"sessions_invalidated":True}
            finally:
                try:os.unlink(tmp)
                except OSError:pass

class ThreadingHTTPServer(ThreadingMixIn,HTTPServer):
    daemon_threads=True; allow_reuse_address=True

class WorksHandler(BaseHTTPRequestHandler):
    server_version="WorksEdition";sys_version=""
    def log_message(self,fmt,*args):
        # Do not log request bodies, credentials, session IDs or query strings.
        sys.stderr.write("%s %s %s\n"%(self.log_date_time_string(),self.client_address[0],fmt%args))
    @property
    def store(self):return self.server.store
    def _headers(self,status=200,content_type="application/json; charset=utf-8",length=None,extra=None):
        self.send_response(status);self.send_header("Content-Type",content_type);self.send_header("X-Content-Type-Options","nosniff");self.send_header("Referrer-Policy","same-origin");self.send_header("X-Frame-Options","DENY");self.send_header("Permissions-Policy","camera=(self), microphone=(), geolocation=()");self.send_header("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'")
        if self.server.secure_cookie:self.send_header("Strict-Transport-Security","max-age=31536000; includeSubDomains")
        if self.path.startswith("/api/"):self.send_header("Cache-Control","no-store")
        if length is not None:self.send_header("Content-Length",str(length))
        if extra:
            for k,v in extra.items():self.send_header(k,v)
        self.end_headers()
    def _json(self,data,status=200,extra=None):
        raw=json.dumps(data,ensure_ascii=False,separators=(",",":")).encode("utf-8");self._headers(status,length=len(raw),extra=extra);self.wfile.write(raw)
    def _read(self,limit=2*1024*1024):
        try:length=int(self.headers.get("Content-Length","0"))
        except ValueError:raise WorksError("Content-Length ungültig.")
        if length<0 or length>limit:raise WorksError(f"Anfrage überschreitet {limit//1024//1024} MB.")
        return self.rfile.read(length)
    def _body(self):
        raw=self._read();
        try:return json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:raise WorksError("JSON-Anfrage ist ungültig.")
    def _cookie_token(self):
        cookie=SimpleCookie();
        try:cookie.load(self.headers.get("Cookie",""))
        except Exception:return ""
        name="__Host-works_session" if self.server.secure_cookie else "works_session"
        return cookie[name].value if name in cookie else ""
    def _session(self):
        session=self.store.get_session(self._cookie_token())
        if not session:raise WorksError("Sitzung abgelaufen. Bitte neu anmelden.","unauthorized")
        return session
    def _csrf(self,session):
        supplied=self.headers.get("X-CSRF-Token","")
        if not supplied or not hmac.compare_digest(supplied,session["csrf"]):raise WorksError("CSRF-Prüfung fehlgeschlagen.","forbidden")
    def _origin(self):
        expected=self.server.public_origin
        origin=self.headers.get("Origin")
        if expected and origin and origin.rstrip("/")!=expected.rstrip("/"):raise WorksError("Fremde Herkunft abgewiesen.","forbidden")
        if not expected and origin:
            host=self.headers.get("Host","")
            scheme="https" if self.server.secure_cookie else "http"
            if origin.rstrip("/")!=f"{scheme}://{host}".rstrip("/"):raise WorksError("Fremde Herkunft abgewiesen.","forbidden")
    def _role(self,session,*roles):
        if session["user"]["role"] not in roles:raise ForbiddenError()
    def _api_error(self,e):
        code=401 if getattr(e,"status","")=="unauthorized" else 403 if getattr(e,"status","")=="forbidden" or getattr(e,"status","")=="denied" else 423 if getattr(e,"status","")=="locked" else 404 if getattr(e,"status","")=="not_found" else 400
        self._json({"error":str(e)},code)
    def do_GET(self):
        path=urlsplit(self.path).path
        if path=="/api/health":return self._json({"ok":True,"app":"SHIFT SUPERVISOR DELUXE WORKS EDITION","version":APP_VERSION,"tls_required_for_pilot":True})
        if path=="/api/me":
            try:s=self._session();return self._json({"user":s["user"],"csrf":s["csrf"],"expires_at":s["expires_at"]})
            except WorksError as e:return self._api_error(e)
        if path.startswith("/api/"):
            try:
                s=self._session();u=s["user"]
                if u.get("must_change"):raise ForbiddenError("Startpasswort muss zuerst geändert werden.")
                if path=="/api/snapshot":return self._json(self.store.snapshot(u))
                if path=="/api/notifications":
                    q=parse_qs(urlsplit(self.path).query);return self._json({"items":self.store.notifications(u,q.get("after",[""])[0])})
                if path=="/api/archive":
                    if u["role"] not in ("ADMINISTRATOR","SHIFT_LEADER","TECHNICIAN"):raise ForbiddenError()
                    q=parse_qs(urlsplit(self.path).query);flt={k:q.get(k,[""])[0] for k in ("from","to","shift","asset","category","status","creator")};return self._json({"items":self.store.archive(u,flt)})
                m=re.fullmatch(r"/api/photos/([A-Za-z0-9_-]{1,64})",path)
                if m:
                    fid=m.group(1)
                    with self.store.lock,self.store.connect() as c:
                        row=c.execute("SELECT f.photo_mime,f.photo_data,f.created_by FROM faults f WHERE f.id=?",(fid,)).fetchone()
                    if not row or not row["photo_data"]:raise WorksError("Foto nicht gefunden.")
                    if u["role"]=="PRODUCTION" and row["created_by"]!=u["id"]:raise ForbiddenError()
                    data=bytes(row["photo_data"]);self._headers(200,row["photo_mime"],len(data),{"Cache-Control":"no-store","Content-Disposition":"inline; filename=\"technikmeldung-foto\""});self.wfile.write(data);return
                if path=="/api/admin/backup":
                    self._role(s,"ADMINISTRATOR");name,blob,manifest=self.store.backup_archive();self._headers(200,"application/zip",len(blob),{"Content-Disposition":f'attachment; filename="{name}"'});self.wfile.write(blob);return
                raise WorksError("API-Endpunkt nicht gefunden.","not_found")
            except WorksError as e:return self._api_error(e)
            except Exception:return self._json({"error":"Interner Serverfehler."},500)
        return self._static(path)
    def _static(self,path):
        rel="index.html" if path in ("/","/index.html") else unquote(path.lstrip("/"))
        root=self.server.app_dir.resolve();target=(root/rel).resolve()
        if root not in target.parents and target!=root:return self._json({"error":"Nicht gefunden."},404)
        if not target.is_file():return self._json({"error":"Nicht gefunden."},404)
        content_type={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".json":"application/json; charset=utf-8",".webmanifest":"application/manifest+json",".svg":"image/svg+xml"}.get(target.suffix,"application/octet-stream")
        data=target.read_bytes();self._headers(200,content_type,len(data),{"Cache-Control":"no-cache" if target.name in ("index.html","sw.js") else "public, max-age=3600"});self.wfile.write(data)
    def do_POST(self):
        path=urlsplit(self.path).path
        try:
            if path=="/api/login":
                self._origin();body=self._body();remote=self.client_address[0]
                user=self.store.authenticate(body.get("username"),body.get("password"),remote);token,csrf,expiry=self.store.create_session(user["id"])
                name="__Host-works_session" if self.server.secure_cookie else "works_session";cookie=f"{name}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=43200"+ ("; Secure" if self.server.secure_cookie else "")
                return self._json({"user":user,"csrf":csrf,"expires_at":expiry},200,{"Set-Cookie":cookie})
            if path.startswith("/api/"):
                session=self._session();self._origin();self._csrf(session);user=session["user"]
                if user.get("must_change") and path not in ("/api/logout","/api/sync"):raise ForbiddenError("Startpasswort muss zuerst geändert werden.")
                if path=="/api/logout":
                    self.store.logout(self._cookie_token());name="__Host-works_session" if self.server.secure_cookie else "works_session";cookie=f"{name}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"+("; Secure" if self.server.secure_cookie else "");return self._json({"ok":True},200,{"Set-Cookie":cookie})
                if path=="/api/sync":
                    body=self._body();ops=body.get("operations",[])
                    if not isinstance(ops,list) or len(ops)>100:raise WorksError("Maximal 100 Synchronisationsvorgänge pro Anfrage.")
                    op_user={**user,"_session_hash":hashlib.sha256(self._cookie_token().encode()).hexdigest()};results=[self.store.apply_operation(op_user,op) for op in ops];return self._json({"results":results,"server_time":now_iso()})
                if path=="/api/notifications/read":
                    body=self._body();ids=body.get("ids",[])
                    if not isinstance(ids,list) or len(ids)>100:raise WorksError("Benachrichtigungsliste ungültig.")
                    for nid in ids:self.store.mark_notification(user,valid_id(nid))
                    return self._json({"ok":True})
                if path=="/api/admin/restore":
                    self._role(session,"ADMINISTRATOR")
                    if self.headers.get("X-Works-Confirm")!="RESTORE":raise WorksError("Wiederherstellung nicht ausdrücklich bestätigt.")
                    data=self._read(100*1024*1024);result=self.store.restore_archive(data,user);return self._json({"ok":True,**result})
                raise WorksError("API-Endpunkt nicht gefunden.","not_found")
            return self._static(path)
        except WorksError as e:return self._api_error(e)
        except Exception as e:return self._json({"error":"Interner Serverfehler."},500)
    def do_OPTIONS(self):
        self._headers(405,"text/plain; charset=utf-8",0)


def main():
    parser=argparse.ArgumentParser(description="SHIFT SUPERVISOR DELUXE Works Edition Server")
    parser.add_argument("command",choices=("init-db","bootstrap-admin","serve"))
    parser.add_argument("--username",default=None);parser.add_argument("--display-name",default=None)
    args=parser.parse_args();root=Path(__file__).resolve().parents[1];var=Path(os.environ.get("WORKS_DATA_DIR",root/"var")).resolve();db=Path(os.environ.get("WORKS_DB",var/"works.sqlite3")).resolve();backups=Path(os.environ.get("WORKS_BACKUP_DIR",var/"backups")).resolve();store=WorksStore(db,backups)
    if args.command=="init-db":
        print(f"Datenbank initialisiert: {db}");print(f"Anlagenstamm: {len(INITIAL_ASSETS)} Anlagen; Status bleibt bis zur Vor-Ort-Bestätigung offen.");return
    if args.command=="bootstrap-admin":
        username=args.username or input("Administrator-Benutzername: ").strip();display=args.display_name or input("Anzeigename: ").strip();import getpass
        password=getpass.getpass("Einmaliges Startpasswort (mind. 12 Zeichen): ");confirm=getpass.getpass("Wiederholen: ")
        if password!=confirm:raise SystemExit("Passwörter stimmen nicht überein.")
        store.bootstrap_admin(username,display,password);print("Administrator angelegt. Es gibt keine Standard-Zugangsdaten.");return
    host=os.environ.get("WORKS_HOST","127.0.0.1")
    # Works can run behind a managed HTTPS platform proxy. Explicit config wins;
    # supported platform hostnames are inferred only when no explicit origin is set.
    port=int(os.environ.get("WORKS_PORT") or os.environ.get("PORT") or "8080")
    secure=os.environ.get("WORKS_SECURE_COOKIE","0")=="1"
    origin=os.environ.get("WORKS_PUBLIC_ORIGIN","").rstrip("/")
    if not origin:
        platform_host=(os.environ.get("RENDER_EXTERNAL_HOSTNAME","").strip() or os.environ.get("RAILWAY_PUBLIC_DOMAIN","").strip())
        if platform_host:
            if "/" in platform_host or ":" in platform_host or "\\" in platform_host:
                raise SystemExit("Abbruch: ungültiger öffentlicher Plattform-Hostname.")
            origin="https://"+platform_host
    if host not in ("127.0.0.1","localhost","::1") and not secure:raise SystemExit("Abbruch: nicht-lokaler Betrieb verlangt WORKS_SECURE_COOKIE=1 hinter freigegebenem HTTPS/TLS-Proxy.")
    if secure and not origin and host not in ("127.0.0.1","localhost","::1"):
        raise SystemExit("Abbruch: für HTTPS-Proxy-Betrieb muss WORKS_PUBLIC_ORIGIN oder ein unterstützter Plattform-Hostname gesetzt sein.")
    server=ThreadingHTTPServer((host,port),WorksHandler);server.store=store;server.app_dir=root/"app";server.secure_cookie=secure;server.public_origin=origin
    print(f"Works Edition {APP_VERSION} listening on {host}:{port}; schema={SCHEMA_VERSION}; app={server.app_dir}")
    if not secure:print("Nur lokale Entwicklung. Kein produktiver Netzwerkbetrieb über unverschlüsseltes HTTP.")
    try:server.serve_forever()
    except KeyboardInterrupt:print("\nServer beendet.")
    finally:server.server_close()

if __name__=="__main__":main()
