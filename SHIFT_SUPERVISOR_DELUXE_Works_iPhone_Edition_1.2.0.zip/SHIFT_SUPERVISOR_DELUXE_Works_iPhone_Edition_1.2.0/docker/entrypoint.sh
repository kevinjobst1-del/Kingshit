#!/bin/sh
set -eu

DATA_DIR="${WORKS_DATA_DIR:-/var/lib/works}"
mkdir -p "$DATA_DIR" "$DATA_DIR/backups"
# Persistent-disk mount points may be root-owned. Prepare the volume, then
# drop privileges before the app process starts.
chown -R works:works "$DATA_DIR"
chmod 0700 "$DATA_DIR" "$DATA_DIR/backups"

# Render/Railway inject PORT at runtime. The app supports PORT as a fallback;
# an explicit WORKS_PORT takes precedence.
if [ -z "${WORKS_PORT:-}" ] && [ -n "${PORT:-}" ]; then
  export WORKS_PORT="$PORT"
fi

gosu works python3 /app/server/works_server.py init-db
exec gosu works python3 /app/server/works_server.py serve
